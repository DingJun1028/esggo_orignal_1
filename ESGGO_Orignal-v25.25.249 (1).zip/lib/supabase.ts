import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://placeholder.supabase.co';
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || 'placeholder-key';

let _client: ReturnType<typeof createClient> | null = null;

export function getSupabaseClient() {
  if (!process.env.NEXT_PUBLIC_SUPABASE_URL) return null;
  if (!_client) {
    _client = createClient(supabaseUrl, supabaseKey);
  }
  return _client;
}

export const supabase = typeof window !== 'undefined' && process.env.NEXT_PUBLIC_SUPABASE_URL
  ? createClient(supabaseUrl, supabaseKey)
  : null;

export default supabase;