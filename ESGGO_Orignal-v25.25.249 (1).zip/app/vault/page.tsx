'use client';
import { useState } from 'react';
import { Database, Upload, CheckCircle, Clock, Shield } from 'lucide-react';

const initialFiles = [
  { id: 1, name: 'ISO 14064-1 盤查清冊.pdf', type: 'PDF', gri: 'GRI 305-1', status: 'verified', uploader: '環安衛主任', date: '2025-05-10', hash: 'a1b2c3d4' },
  { id: 2, name: '台電電費帳單_Q1.pdf', type: 'PDF', gri: 'GRI 302-1', status: 'verified', uploader: '總務部門', date: '2025-05-08', hash: 'b2c3d4e5' },
  { id: 3, name: '水權狀.pdf', type: 'PDF', gri: 'GRI 303-1', status: 'pending', uploader: '廠務部門', date: '2025-05-15', hash: 'c3d4e5f6' },
  { id: 4, name: '供應商永續承諾書.xlsx', type: 'XLSX', gri: 'GRI 308-1', status: 'pending', uploader: '採購部門', date: '2025-05-16', hash: 'd4e5f6a1' },
];

export default function VaultPage() {
  const [files, setFiles] = useState(initialFiles);
  const [search, setSearch] = useState('');
  const filtered = files.filter(f => f.name.includes(search) || f.gri.includes(search));

  const verify = (id: number) => setFiles(prev => prev.map(f => f.id === id ? { ...f, status: 'verified' } : f));

  return (
    <div className="fade-in" style={{ maxWidth: 1200 }}>
      <div className="page-header">
        <div className="page-eyebrow"><Database size={12} /> 5T 誠信協議 · ZKP 零知識證明</div>
        <h1 className="page-title">證據金庫 Evidence Vault</h1>
        <p className="page-sub">集中化數據存證 · SHA-256 封印 · ZKP 驗算</p>
      </div>

      <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
        <input className="inp" style={{ flex: 1, minWidth: 200 }} placeholder="搜尋文件、GRI 指標..."
          value={search} onChange={e => setSearch(e.target.value)} />
        <button className="btn btn-primary btn-sm"><Upload size={14} /> 上傳佐證</button>
      </div>

      <div className="card">
        <div className="tbl-wrap">
          <table className="tbl">
            <thead>
              <tr><th>文件名稱</th><th>GRI</th><th>上傳者</th><th>日期</th><th>Hash</th><th>ZKP</th><th>操作</th></tr>
            </thead>
            <tbody>
              {filtered.map(f => (
                <tr key={f.id}>
                  <td style={{ fontWeight: 600, maxWidth: 200 }}>
                    <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{f.name}</div>
                  </td>
                  <td><span className="badge badge-blue">{f.gri}</span></td>
                  <td style={{ color: '#94a3b8', fontSize: '0.78rem' }}>{f.uploader}</td>
                  <td style={{ color: '#94a3b8', fontSize: '0.78rem' }}>{f.date}</td>
                  <td><code style={{ fontSize: '0.68rem', background: '#f8fafc', padding: '2px 5px', borderRadius: 4 }}>{f.hash}...</code></td>
                  <td>
                    {f.status === 'verified'
                      ? <span style={{ display: 'flex', alignItems: 'center', gap: 4, color: '#00A598', fontSize: '0.72rem', fontWeight: 700 }}><CheckCircle size={12} />已驗</span>
                      : <span style={{ display: 'flex', alignItems: 'center', gap: 4, color: '#FDB515', fontSize: '0.72rem', fontWeight: 700 }}><Clock size={12} />待驗</span>
                    }
                  </td>
                  <td>
                    {f.status === 'pending'
                      ? <button className="btn btn-teal btn-xs" onClick={() => verify(f.id)}><Shield size={11} /> ZKP</button>
                      : <button className="btn btn-ghost btn-xs">詳情</button>
                    }
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}