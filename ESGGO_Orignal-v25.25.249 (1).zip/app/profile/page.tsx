'use client';
import { useState } from 'react';
import { Building2, Edit2, Save } from 'lucide-react';

export default function ProfilePage() {
  const [editing, setEditing] = useState(false);
  const [profile, setProfile] = useState({
    name: '善向永續科技股份有限公司', industry: '科技製造業', employees: 1250, revenue: '28億TWD',
    locations: '台北、新竹、高雄', reportYear: 2024, vision: '成為台灣中小企業 ESG 轉型的標竿企業',
    mission: '透過數位科技與永續創新，實現環境友善、社會共好、治理透明的企業目標',
  });

  return (
    <div className="fade-in" style={{ maxWidth: 900 }}>
      <div className="page-header">
        <div className="page-eyebrow"><Building2 size={12} /> 企業管理</div>
        <h1 className="page-title">企業管理 Profile</h1>
        <p className="page-sub">公司基本資料 · 治理目標 · ESG 願景</p>
      </div>

      <div className="card" style={{ padding: '2rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
          <h3 style={{ fontWeight: 800, fontSize: '1.1rem' }}>基本資料</h3>
          <button className="btn btn-ghost btn-sm" onClick={() => setEditing(!editing)}>
            {editing ? <><Save size={14} /> 儲存</> : <><Edit2 size={14} /> 編輯</>}
          </button>
        </div>

        <div className="g-2" style={{ gap: '1.25rem' }}>
          {[
            { label: '公司名稱', key: 'name' },
            { label: '產業別', key: 'industry' },
            { label: '員工人數', key: 'employees' },
            { label: '年營收', key: 'revenue' },
            { label: '服務據點', key: 'locations' },
            { label: '報告年度', key: 'reportYear' },
          ].map(field => (
            <div key={field.key}>
              <label className="inp-label">{field.label}</label>
              {editing ? (
                <input className="inp" value={String(profile[field.key as keyof typeof profile])}
                  onChange={e => setProfile(prev => ({ ...prev, [field.key]: e.target.value }))} />
              ) : (
                <div style={{ padding: '0.625rem 0', fontWeight: 600, borderBottom: '1px solid #f1f5f9' }}>
                  {String(profile[field.key as keyof typeof profile])}
                </div>
              )}
            </div>
          ))}
        </div>

        <div style={{ marginTop: '1.5rem', paddingTop: '1.5rem', borderTop: '1px solid #f1f5f9' }}>
          <label className="inp-label">企業願景</label>
          {editing ? (
            <textarea className="inp" style={{ height: 80, resize: 'none' }} value={profile.vision}
              onChange={e => setProfile(prev => ({ ...prev, vision: e.target.value }))} />
          ) : (
            <div style={{ padding: '0.625rem 0', lineHeight: 1.7 }}>{profile.vision}</div>
          )}
          <label className="inp-label" style={{ marginTop: '1rem' }}>企業使命</label>
          {editing ? (
            <textarea className="inp" style={{ height: 80, resize: 'none' }} value={profile.mission}
              onChange={e => setProfile(prev => ({ ...prev, mission: e.target.value }))} />
          ) : (
            <div style={{ padding: '0.625rem 0', lineHeight: 1.7 }}>{profile.mission}</div>
          )}
        </div>
      </div>
    </div>
  );
}