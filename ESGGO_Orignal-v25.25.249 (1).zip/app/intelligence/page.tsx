'use client';
import { useState } from 'react';
import { Activity, ExternalLink } from 'lucide-react';

const news = [
  { title: '金管會發布上市櫃公司永續報告書新規範，2025年全面適用', category: '法規動態', impact: '高', date: '2025-05-10', source: '金管會', url: 'https://www.fsc.gov.tw', tags: ['GRI 2021', 'ISSB', '金管會'] },
  { title: 'EU CBAM 碳邊境調整機制正式生效，台灣出口商須準備碳足跡文件', category: '碳政策', impact: '高', date: '2025-05-08', source: '歐盟執委會', url: 'https://ec.europa.eu', tags: ['CBAM', '碳邊境', 'EU'] },
  { title: 'SBTi 正式採納 ISSB S2 氣候相關揭露標準', category: '國際標準', impact: '中', date: '2025-05-06', source: 'SBTi', url: 'https://sciencebasedtargets.org', tags: ['SBTi', 'ISSB S2', 'Scope 3'] },
  { title: 'ISSA 5000 永續確信標準發布，強化第三方查證要求', category: '確信標準', impact: '中', date: '2025-05-03', source: 'IAASB', url: 'https://www.iaasb.org', tags: ['ISSA 5000', 'ESG 確信'] },
];

const impactColors: Record<string, string> = { '高': '#ED4E33', '中': '#FDB515', '低': '#00A598' };
const cats = ['全部', '法規動態', '碳政策', '國際標準', '確信標準'];

export default function IntelligencePage() {
  const [filter, setFilter] = useState('全部');
  const filtered = filter === '全部' ? news : news.filter(n => n.category === filter);

  return (
    <div className="fade-in" style={{ maxWidth: 1100 }}>
      <div className="page-header">
        <div className="page-eyebrow"><Activity size={12} /> ESG 法規情報 · 產業標竿</div>
        <h1 className="page-title">商情中心 Intelligence Hub</h1>
        <p className="page-sub">即時 ESG 法規動態 · 國際標準追蹤 · 風險預警</p>
      </div>

      <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
        {cats.map(c => (
          <button key={c} onClick={() => setFilter(c)} style={{
            padding: '0.375rem 0.875rem', borderRadius: 99, border: 'none', cursor: 'pointer',
            fontSize: '0.78rem', fontWeight: 600,
            background: filter === c ? '#003262' : 'white', color: filter === c ? 'white' : '#475569',
            boxShadow: '0 1px 3px rgba(0,0,0,0.06)',
          }}>{c}</button>
        ))}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
        {filtered.map((item, i) => (
          <div key={i} className="card" style={{ padding: '1.25rem', borderLeft: `4px solid ${impactColors[item.impact]}` }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '1rem', flexWrap: 'wrap' }}>
              <div style={{ flex: 1, minWidth: 200 }}>
                <div style={{ display: 'flex', gap: '0.4rem', marginBottom: '0.5rem', flexWrap: 'wrap' }}>
                  <span className="badge" style={{ background: `${impactColors[item.impact]}15`, color: impactColors[item.impact] }}>{item.impact}衝擊</span>
                  <span className="badge badge-gray">{item.category}</span>
                  <span style={{ fontSize: '0.7rem', color: '#94a3b8', display: 'flex', alignItems: 'center' }}>{item.date}</span>
                </div>
                <h3 style={{ fontWeight: 700, fontSize: '0.95rem', marginBottom: '0.5rem', lineHeight: 1.5 }}>{item.title}</h3>
                <div style={{ display: 'flex', gap: '0.35rem', flexWrap: 'wrap' }}>
                  {item.tags.map(tag => <span key={tag} className="badge badge-blue badge-sm">{tag}</span>)}
                </div>
              </div>
              <a href={item.url} target="_blank" rel="noreferrer" className="btn btn-ghost btn-sm" style={{ flexShrink: 0 }}>
                {item.source} <ExternalLink size={11} />
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}