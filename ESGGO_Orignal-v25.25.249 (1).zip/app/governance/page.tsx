'use client';
import { Shield, CheckCircle } from 'lucide-react';

const metrics = [
  { cat: '董事會', name: '董事會人數', value: 9, unit: '人', gri: 'GRI 2-9', ok: true },
  { cat: '董事會', name: '獨立董事比例', value: '33.3', unit: '%', gri: 'GRI 2-9', ok: true },
  { cat: '董事會', name: '女性董事比例', value: '22.2', unit: '%', gri: 'GRI 405-1', ok: true },
  { cat: '誠信', name: '貪腐事件數', value: 0, unit: '件', gri: 'GRI 205-3', ok: true },
  { cat: '誠信', name: '法規罰款金額', value: 0, unit: 'TWD', gri: 'GRI 206-1', ok: true },
  { cat: '稅務', name: '有效稅率', value: '20.5', unit: '%', gri: 'GRI 207-4', ok: false },
];

const catColors: Record<string, string> = { '董事會': '#003262', '誠信': '#822980', '稅務': '#FDB515' };

export default function GovernancePage() {
  return (
    <div className="fade-in" style={{ maxWidth: 1100 }}>
      <div className="page-header">
        <div className="page-eyebrow"><Shield size={12} /> GRI 2 · 205-207 · 公司治理</div>
        <h1 className="page-title">公司治理中心</h1>
        <p className="page-sub">董事會結構 · 商業誠信 · 稅務透明</p>
      </div>
      <div className="g-3" style={{ marginBottom: '1.25rem' }}>
        {[
          { label: '董事會人數', value: '9', unit: '位', color: '#003262' },
          { label: '獨立董事', value: '33.3%', unit: '', color: '#822980' },
          { label: '貪腐事件', value: '0', unit: '件', color: '#00A598' },
        ].map((s, i) => (
          <div key={i} className="card kpi-card" style={{ borderTop: `3px solid ${s.color}` }}>
            <div className="kpi-label">{s.label}</div>
            <div className="kpi-value" style={{ color: s.color }}>{s.value}</div>
            <div style={{ fontSize: '0.7rem', color: '#94a3b8' }}>{s.unit}</div>
          </div>
        ))}
      </div>
      <div className="card">
        <div className="tbl-wrap">
          <table className="tbl">
            <thead><tr><th>類別</th><th>指標</th><th>數值</th><th>GRI</th><th>狀態</th></tr></thead>
            <tbody>
              {metrics.map((m, i) => (
                <tr key={i}>
                  <td><span className="badge" style={{ background: `${catColors[m.cat]}15`, color: catColors[m.cat] }}>{m.cat}</span></td>
                  <td style={{ fontWeight: 600 }}>{m.name}</td>
                  <td style={{ fontWeight: 700, fontFamily: 'monospace' }}>{m.value} {m.unit}</td>
                  <td><span className="badge badge-blue">{m.gri}</span></td>
                  <td>{m.ok ? <CheckCircle size={15} color="#00A598" /> : <span className="badge badge-gray">待補</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}