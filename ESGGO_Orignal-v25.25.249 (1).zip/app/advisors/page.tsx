'use client';
import { Briefcase } from 'lucide-react';

const advisors = [
  { name: '楊坤修 博士', role: '理事長', org: '台灣社會創新與永續發展協會', available: true, rating: 4.9, sessions: 238, specialty: 'ESG 治理' },
  { name: 'Dr. Kuen-Shiou Yang', role: 'Chairman', org: 'TSISDA', available: true, rating: 4.9, sessions: 238, specialty: '永續轉型' },
  { name: 'Ganesh Iyer', role: 'Faculty Director', org: 'UC Berkeley Haas', available: false, rating: 4.8, sessions: 189, specialty: '成長市場' },
];

export default function AdvisorsPage() {
  return (
    <div className="fade-in" style={{ maxWidth: 1100 }}>
      <div className="page-header">
        <div className="page-eyebrow"><Briefcase size={12} /> Berkeley Haas × TSISDA 顧問專區</div>
        <h1 className="page-title">顧問專區 Advisory Council</h1>
        <p className="page-sub">頂尖 ESG 顧問專家 · 精準諮詢媒合</p>
      </div>

      <div className="g-auto">
        {advisors.map((a, i) => (
          <div key={i} className="card card-hover" style={{ padding: '1.5rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
              <div style={{ width: 48, height: 48, borderRadius: '50%', background: '#003262', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#FDB515', fontWeight: 800, flexShrink: 0 }}>
                {a.name.charAt(0)}
              </div>
              <div>
                <div style={{ fontWeight: 800 }}>{a.name}</div>
                <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{a.role} · {a.org}</div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1rem' }}>
              <span className={`badge ${a.available ? 'badge-green' : 'badge-gray'}`}>{a.available ? '可預約' : '已滿'}</span>
              <span className="badge badge-blue">{a.specialty}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: '#94a3b8', marginBottom: '1rem' }}>
              <span>⭐ {a.rating}</span>
              <span>{a.sessions} 場諮詢</span>
            </div>
            <button className="btn btn-primary btn-sm" style={{ width: '100%', justifyContent: 'center' }} disabled={!a.available}>
              {a.available ? '預約諮詢' : '暫不開放'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}