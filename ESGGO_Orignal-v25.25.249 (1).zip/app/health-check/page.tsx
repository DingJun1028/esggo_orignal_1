'use client';
import { useState } from 'react';
import { Heart, CheckCircle, XCircle, AlertCircle } from 'lucide-react';

const questions = [
  { id: 1, cat: 'E', text: '公司是否完成溫室氣體 (GHG) 盤查？', gri: 'GRI 305-1' },
  { id: 2, cat: 'E', text: '是否建立能源管理制度並追蹤用電量？', gri: 'GRI 302-1' },
  { id: 3, cat: 'E', text: '是否訂定減碳目標 (如 SBTi)？', gri: 'GRI 305-4' },
  { id: 4, cat: 'S', text: '是否進行員工薪酬公平性分析？', gri: 'GRI 405-2' },
  { id: 5, cat: 'S', text: '是否建立職業安全衛生管理體系？', gri: 'GRI 403-1' },
  { id: 6, cat: 'S', text: '是否對供應商進行 ESG 評估？', gri: 'GRI 308-1' },
  { id: 7, cat: 'G', text: '董事會是否包含獨立董事？', gri: 'GRI 2-9' },
  { id: 8, cat: 'G', text: '是否建立反貪腐政策與申訴機制？', gri: 'GRI 205-1' },
  { id: 9, cat: 'G', text: '是否進行重大性評估？', gri: 'GRI 3-1' },
];

type Answer = 'yes' | 'partial' | 'no' | null;
const weights: Record<NonNullable<Answer>, number> = { yes: 100, partial: 50, no: 0 };

export default function HealthCheckPage() {
  const [answers, setAnswers] = useState<Record<number, Answer>>({});
  const [submitted, setSubmitted] = useState(false);

  const answered = Object.keys(answers).length;
  const score = answered > 0 ? Math.round(Object.values(answers).reduce((s, a) => s + (a ? weights[a] : 0), 0) / questions.length) : 0;

  const catScore = (cat: string) => {
    const qs = questions.filter(q => q.cat === cat);
    const total = qs.reduce((s, q) => s + (answers[q.id] ? weights[answers[q.id]!] : 0), 0);
    return Math.round(total / qs.length);
  };

  return (
    <div className="fade-in" style={{ maxWidth: 900 }}>
      <div className="page-header">
        <div className="page-eyebrow"><Heart size={12} /> ESG 自評 · 15 題健檢</div>
        <h1 className="page-title">企業健檢 Health Check</h1>
        <p className="page-sub">快速評估 ESG 現況 · 生成 90 天改善路線圖</p>
      </div>

      {!submitted ? (
        <>
          <div className="card" style={{ padding: '1.5rem', marginBottom: '1rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ fontWeight: 700 }}>完成進度: {answered}/{questions.length}</div>
              <div style={{ fontWeight: 800, fontSize: '1.25rem', color: '#003262' }}>{score}%</div>
            </div>
            <div className="progress-track" style={{ marginTop: '0.75rem' }}>
              <div className="progress-fill" style={{ width: `${(answered / questions.length) * 100}%`, background: '#003262' }} />
            </div>
          </div>

          {['E', 'S', 'G'].map(cat => (
            <div key={cat} style={{ marginBottom: '1.5rem' }}>
              <div style={{ fontWeight: 800, fontSize: '0.9rem', marginBottom: '0.75rem', color: '#475569' }}>
                {cat === 'E' ? '🌿 環境面 (Environment)' : cat === 'S' ? '👥 社會面 (Social)' : '🏛️ 治理面 (Governance)'}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {questions.filter(q => q.cat === cat).map(q => (
                  <div key={q.id} className="card" style={{ padding: '1.25rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
                      <div>
                        <div style={{ fontWeight: 600, fontSize: '0.875rem', marginBottom: 4 }}>{q.text}</div>
                        <span className="badge badge-blue" style={{ fontSize: '0.6rem' }}>{q.gri}</span>
                      </div>
                      <div style={{ display: 'flex', gap: '0.5rem', flexShrink: 0 }}>
                        {(['yes', 'partial', 'no'] as Answer[]).map(opt => (
                          <button key={opt as string} onClick={() => setAnswers(prev => ({ ...prev, [q.id]: opt }))}
                            style={{
                              padding: '0.4rem 0.75rem', borderRadius: 8, border: 'none', cursor: 'pointer', fontSize: '0.75rem', fontWeight: 600,
                              background: answers[q.id] === opt ? (opt === 'yes' ? '#003262' : opt === 'partial' ? '#FDB515' : '#ED4E33') : '#f1f5f9',
                              color: answers[q.id] === opt ? 'white' : '#475569',
                            }}>
                            {opt === 'yes' ? '✅ 是' : opt === 'partial' ? '⚠️ 部分' : '❌ 否'}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}

          <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', padding: '0.875rem' }}
            onClick={() => setSubmitted(true)} disabled={answered < questions.length}>
            提交健檢結果 ({answered}/{questions.length})
          </button>
        </>
      ) : (
        <div className="card" style={{ padding: '2rem' }}>
          <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
            <div style={{ fontSize: '4rem', fontWeight: 900, color: score > 70 ? '#00A598' : score > 40 ? '#FDB515' : '#ED4E33' }}>{score}%</div>
            <div style={{ fontWeight: 700, fontSize: '1.1rem', color: '#003262' }}>ESG 健檢分數</div>
          </div>
          <div className="g-3">
            {['E', 'S', 'G'].map(cat => {
              const s = catScore(cat);
              return (
                <div key={cat} className="card" style={{ padding: '1.25rem', textAlign: 'center' }}>
                  <div style={{ fontSize: '1.75rem', fontWeight: 900, color: s > 70 ? '#00A598' : '#FDB515' }}>{s}%</div>
                  <div style={{ fontWeight: 700, fontSize: '0.8rem', color: '#475569', marginTop: 4 }}>
                    {cat === 'E' ? '環境' : cat === 'S' ? '社會' : '治理'}
                  </div>
                </div>
              );
            })}
          </div>
          <button className="btn btn-ghost" style={{ width: '100%', justifyContent: 'center', marginTop: '1.5rem' }}
            onClick={() => { setSubmitted(false); setAnswers({}); }}>
            重新健檢
          </button>
        </div>
      )}
    </div>
  );
}