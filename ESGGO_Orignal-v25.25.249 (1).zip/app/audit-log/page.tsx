'use client';
import { useState } from 'react';
import { ClipboardList, Clock } from 'lucide-react';

const logs = [
  { id: 1, action: '提交 GRI 305-1 碳排數據', module: 'Environmental', actor: '環安衛主任', tag: 'T1', hash: 'a1b2...', time: '2025-05-17 14:32', status: 'success' },
  { id: 2, action: 'VerifyLink™ ZKP 驗算完成', module: 'Vault', actor: '系統自動', tag: 'T4', hash: 'b2c3...', time: '2025-05-17 13:15', status: 'success' },
  { id: 3, action: '更新供應商 ESG 評分', module: 'Supply Chain', actor: '採購部門', tag: 'T5', hash: 'c3d4...', time: '2025-05-17 12:08', status: 'success' },
  { id: 4, action: '偵測潛在綠漂風險', module: 'Advisory', actor: 'AI 合規守衛', tag: 'T2', hash: 'd4e5...', time: '2025-05-17 11:22', status: 'warning' },
  { id: 5, action: '新增員工結構數據', module: 'Social', actor: '人資部門', tag: 'T1', hash: 'e5f6...', time: '2025-05-17 10:45', status: 'success' },
];

const tagColors: Record<string, string> = { T1: '#003262', T2: '#FDB515', T3: '#3B7EA1', T4: '#822980', T5: '#00A598' };

export default function AuditLogPage() {
  const [search, setSearch] = useState('');
  const filtered = logs.filter(l => l.action.includes(search) || l.actor.includes(search));

  return (
    <div className="fade-in" style={{ maxWidth: 1200 }}>
      <div className="page-header">
        <div className="page-eyebrow"><ClipboardList size={12} /> 5T 不可篡改軌跡</div>
        <h1 className="page-title">審計日誌 Audit Log</h1>
        <p className="page-sub">所有 ESG 數據操作的完整追蹤記錄</p>
      </div>
      <div style={{ marginBottom: '1rem' }}>
        <input className="inp" placeholder="搜尋操作、人員..." value={search}
          onChange={e => setSearch(e.target.value)} style={{ maxWidth: 420 }} />
      </div>
      <div className="card">
        <div className="tbl-wrap">
          <table className="tbl">
            <thead>
              <tr><th>5T</th><th>操作描述</th><th>模組</th><th>執行者</th><th>雜湊</th><th>時間</th><th>狀態</th></tr>
            </thead>
            <tbody>
              {filtered.map(log => (
                <tr key={log.id}>
                  <td><span className="badge" style={{ background: `${tagColors[log.tag]}15`, color: tagColors[log.tag] }}>{log.tag}</span></td>
                  <td style={{ fontWeight: 600, maxWidth: 240 }}>
                    <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{log.action}</div>
                  </td>
                  <td><span className="badge badge-gray">{log.module}</span></td>
                  <td style={{ color: '#475569', fontSize: '0.8rem' }}>{log.actor}</td>
                  <td><code style={{ fontSize: '0.68rem', background: '#f8fafc', padding: '2px 5px', borderRadius: 4 }}>{log.hash}</code></td>
                  <td style={{ color: '#94a3b8', fontSize: '0.75rem', whiteSpace: 'nowrap' }}><Clock size={10} style={{ verticalAlign: 'middle', marginRight: 3 }} />{log.time}</td>
                  <td><span className={`badge ${log.status === 'success' ? 'badge-green' : 'badge-gold'}`}>{log.status === 'success' ? '成功' : '警示'}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}