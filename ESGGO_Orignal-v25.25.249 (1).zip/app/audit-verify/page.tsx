'use client';
import { useState } from 'react';
import { BadgeCheck, Shield, CheckCircle, XCircle } from 'lucide-react';

export default function AuditVerifyPage() {
  const [hash, setHash] = useState('');
  const [result, setResult] = useState<'pass' | 'fail' | null>(null);

  const verify = () => {
    if (hash.length >= 8) setResult('pass');
    else setResult('fail');
  };

  return (
    <div className="fade-in" style={{ maxWidth: 800 }}>
      <div className="page-header">
        <div className="page-eyebrow"><BadgeCheck size={12} /> ZKP 零知識證明 · 不可篡改驗算</div>
        <h1 className="page-title">VerifyLink™ 審計驗算</h1>
        <p className="page-sub">外部審計師入口 · ZKP 驗算 · SHA-256 完整性核查</p>
      </div>

      <div className="card" style={{ padding: '2rem', marginBottom: '1.5rem' }}>
        <h3 style={{ fontWeight: 800, fontSize: '1rem', marginBottom: '1rem' }}>輸入 Hash 指紋驗算</h3>
        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <input className="inp" placeholder="輸入 SHA-256 雜湊值..." value={hash} onChange={e => setHash(e.target.value)} style={{ flex: 1, fontFamily: 'monospace' }} />
          <button className="btn btn-primary" onClick={verify}><Shield size={16} /> 驗算</button>
        </div>

        {result && (
          <div style={{ marginTop: '1.5rem', padding: '1.5rem', borderRadius: 10, background: result === 'pass' ? '#f0fdf4' : '#fef2f2', border: `1px solid ${result === 'pass' ? '#bbf7d0' : '#fecaca'}`, textAlign: 'center' }}>
            {result === 'pass' ? (
              <>
                <CheckCircle size={32} color="#00A598" style={{ margin: '0 auto 0.75rem' }} />
                <div style={{ fontWeight: 800, color: '#003262', fontSize: '1.1rem' }}>✅ ZKP 驗算通過</div>
                <div style={{ color: '#94a3b8', fontSize: '0.8rem', marginTop: '0.5rem' }}>此雜湊值在系統中已核實，數據未被篡改</div>
              </>
            ) : (
              <>
                <XCircle size={32} color="#ED4E33" style={{ margin: '0 auto 0.75rem' }} />
                <div style={{ fontWeight: 800, color: '#ED4E33', fontSize: '1.1rem' }}>❌ 驗算失敗</div>
                <div style={{ color: '#94a3b8', fontSize: '0.8rem', marginTop: '0.5rem' }}>雜湊值無效或數據可能已被修改</div>
              </>
            )}
          </div>
        )}
      </div>

      <div className="card" style={{ padding: '1.5rem' }}>
        <h3 style={{ fontWeight: 800, fontSize: '0.9rem', marginBottom: '1rem' }}>5T 協議說明</h3>
        {[
          { tag: 'T1', label: '可溯源 Traceable', desc: '每筆數據與原始憑證精確關聯' },
          { tag: 'T2', label: '透明 Transparent', desc: '算法公開，主動掃描綠漂風險' },
          { tag: 'T4', label: '不可篡改 Trustworthy', desc: 'SHA-256 雜湊鎖定，ADK Integrity Proof' },
          { tag: 'T5', label: '可追蹤 Trackable', desc: '完整編輯軌跡，AuditRecord 記錄' },
        ].map((item, i) => (
          <div key={i} style={{ display: 'flex', gap: '1rem', padding: '0.75rem 0', borderBottom: '1px solid #f8fafc' }}>
            <span className="badge badge-blue" style={{ flexShrink: 0 }}>{item.tag}</span>
            <div>
              <div style={{ fontWeight: 700, fontSize: '0.83rem' }}>{item.label}</div>
              <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{item.desc}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}