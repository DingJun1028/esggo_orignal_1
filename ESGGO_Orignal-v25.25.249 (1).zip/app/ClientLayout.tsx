'use client';

import { useState, useEffect, useCallback } from 'react';
import { usePathname } from 'next/navigation';
import Link from 'next/link';
import {
  LayoutDashboard, FileText, Bot, Activity, Leaf, Users, Shield,
  BarChart3, BookOpen, ClipboardList, Database, Route,
  Send, Library, TrendingUp, Truck, UserCheck,
  Settings, ChevronLeft, ChevronRight, Menu, X, Building2,
  CheckSquare, Fingerprint, GraduationCap,
  Briefcase, Network, Cpu, BadgeCheck, Heart, Search
} from 'lucide-react';

const navGroups = [
  {
    title: 'CORE',
    items: [
      { href: '/', label: '控制台', sub: 'Dashboard', icon: LayoutDashboard },
      { href: '/editor', label: '永續撰寫', sub: 'SustainWrite', icon: FileText },
      { href: '/digital-twin', label: '數位分身', sub: 'Digital Twin', icon: Fingerprint },
      { href: '/health-check', label: '企業健檢', sub: 'Health Check', icon: Heart },
      { href: '/advisory', label: '專家諮詢', sub: 'Advisory', icon: Bot },
      { href: '/intelligence', label: '商情中心', sub: 'Intelligence', icon: Activity },
    ],
  },
  {
    title: 'E-S-G MODULES',
    items: [
      { href: '/environmental', label: '環境指揮', sub: 'Environmental', icon: Leaf },
      { href: '/social', label: '社會影響', sub: 'Social', icon: Users },
      { href: '/governance', label: '公司治理', sub: 'Governance', icon: Shield },
    ],
  },
  {
    title: 'GOVERNANCE',
    items: [
      { href: '/materiality', label: '重大性矩陣', sub: 'Materiality', icon: BarChart3 },
      { href: '/templates', label: '專家模板', sub: 'Templates', icon: BookOpen },
      { href: '/audit-log', label: '審計日誌', sub: 'Audit Log', icon: ClipboardList },
      { href: '/vault', label: '證據金庫', sub: 'Evidence Vault', icon: Database },
    ],
  },
  {
    title: 'INSIGHTS',
    items: [
      { href: '/roadmap', label: '淨零路線圖', sub: 'Net-Zero', icon: Route },
      { href: '/publish', label: '報告發布', sub: 'Publish', icon: Send },
      { href: '/reading-room', label: '永續閱覽室', sub: 'Reading Room', icon: Library },
      { href: '/library', label: '永續智庫', sub: 'Library', icon: BookOpen },
      { href: '/finance', label: '永續財務', sub: 'Finance', icon: TrendingUp },
      { href: '/supply-chain', label: '供應鏈透明', sub: 'Supply Chain', icon: Truck },
      { href: '/stakeholders', label: '利害關係人', sub: 'Stakeholders', icon: UserCheck },
      { href: '/audit-verify', label: 'VerifyLink™', sub: 'ZKP Verify', icon: BadgeCheck },
    ],
  },
  {
    title: 'ACADEMY',
    items: [
      { href: '/academy', label: '永續學院', sub: 'Academy', icon: GraduationCap },
      { href: '/advisors', label: '顧問專區', sub: 'Advisors', icon: Briefcase },
      { href: '/agents', label: '代理專區', sub: 'Agents', icon: Network },
      { href: '/consulting', label: '顧問服務', sub: 'Consulting', icon: Search },
    ],
  },
  {
    title: 'SYSTEM',
    items: [
      { href: '/tasks', label: '任務中心', sub: 'Tasks', icon: CheckSquare },
      { href: '/profile', label: '企業管理', sub: 'Profile', icon: Building2 },
      { href: '/api-setup', label: '整合中心', sub: 'API Setup', icon: Settings },
      { href: '/swarm', label: 'Hermes Swarm', sub: 'AI Swarm', icon: Cpu },
    ],
  },
];

const mobileNavItems = [
  { href: '/', label: '控制台', icon: LayoutDashboard },
  { href: '/environmental', label: '環境', icon: Leaf },
  { href: '/editor', label: '撰寫', icon: FileText },
  { href: '/advisory', label: '諮詢', icon: Bot },
  { href: '/vault', label: '金庫', icon: Database },
];

export default function ClientLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname() ?? '/';
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    try {
      const saved = localStorage.getItem('sidebar-collapsed');
      if (saved === 'true') setCollapsed(true);
    } catch {}
  }, []);

  // Close mobile drawer on route change
  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  // Lock body scroll when mobile drawer is open
  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [mobileOpen]);

  const toggleCollapse = useCallback(() => {
    setCollapsed(prev => {
      const next = !prev;
      try { localStorage.setItem('sidebar-collapsed', String(next)); } catch {}
      return next;
    });
  }, []);

  const isActive = useCallback((href: string) => {
    if (href === '/') return pathname === '/';
    return pathname.startsWith(href);
  }, [pathname]);

  // SSR: render without sidebar to avoid hydration mismatch
  if (!mounted) {
    return (
      <div className="app-layout">
        <div style={{ width: 256, minWidth: 256, background: '#001b36', position: 'fixed', top: 0, left: 0, height: '100vh', zIndex: 200 }} />
        <main style={{ marginLeft: 256, padding: '1.75rem', minHeight: '100vh' }}>{children}</main>
      </div>
    );
  }

  return (
    <div className="app-layout">
      {/* ── Mobile header ─────────────────────────── */}
      <header className="mobile-header">
        <button
          onClick={() => setMobileOpen(true)}
          aria-label="開啟導航"
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#003262', padding: '0.5rem', display: 'flex' }}
        >
          <Menu size={22} />
        </button>
        <div style={{ fontWeight: 900, fontSize: '1rem', color: '#003262', letterSpacing: '-0.02em' }}>
          ESG GO <span style={{ color: '#FDB515' }}>善向永續</span>
        </div>
        <div style={{ width: 38 }} />
      </header>

      {/* ── Mobile overlay ────────────────────────── */}
      {mobileOpen && (
        <div
          className="mobile-overlay visible"
          onClick={() => setMobileOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* ── Sidebar ───────────────────────────────── */}
      <nav
        className={`sidebar-nav${collapsed ? ' collapsed' : ''}${mobileOpen ? ' mobile-open' : ''}`}
        aria-label="主導航"
      >
        {/* Logo */}
        <div style={{
          padding: collapsed ? '1rem 0' : '1rem 0.875rem',
          borderBottom: '1px solid rgba(255,255,255,0.08)',
          display: 'flex', alignItems: 'center',
          justifyContent: collapsed ? 'center' : 'space-between',
          flexShrink: 0,
        }}>
          {!collapsed && (
            <div style={{ minWidth: 0 }}>
              <div style={{ fontWeight: 900, fontSize: '1rem', color: 'white', letterSpacing: '-0.02em' }}>
                ESG GO
              </div>
              <div style={{ fontSize: '0.58rem', color: 'rgba(255,255,255,0.4)', marginTop: 2 }}>
                善向永續 v8.5.0
              </div>
            </div>
          )}
          {/* Desktop collapse toggle */}
          <button
            onClick={toggleCollapse}
            aria-label={collapsed ? '展開側邊欄' : '收合側邊欄'}
            className="desktop-collapse-btn"
            style={{
              background: 'rgba(255,255,255,0.08)', border: 'none',
              color: 'rgba(255,255,255,0.6)', borderRadius: 6,
              width: 28, height: 28, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0,
            }}
          >
            {collapsed ? <ChevronRight size={13} /> : <ChevronLeft size={13} />}
          </button>
          {/* Mobile close button */}
          <button
            onClick={() => setMobileOpen(false)}
            aria-label="關閉導航"
            className="mobile-close-btn"
            style={{
              background: 'rgba(255,255,255,0.08)', border: 'none',
              color: 'rgba(255,255,255,0.6)', borderRadius: 6,
              width: 28, height: 28, cursor: 'pointer',
              alignItems: 'center', justifyContent: 'center',
              flexShrink: 0, display: 'none',
            }}
          >
            <X size={14} />
          </button>
        </div>

        {/* Nav groups */}
        <div style={{ flex: 1, overflowY: 'auto', paddingBottom: '1rem', scrollbarWidth: 'none' }}>
          {navGroups.map((group) => (
            <div key={group.title}>
              {!collapsed && (
                <div className="nav-group-title">{group.title}</div>
              )}
              {group.items.map((item) => {
                const Icon = item.icon;
                const active = isActive(item.href);
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`nav-item${active ? ' active' : ''}`}
                    title={collapsed ? item.label : undefined}
                    aria-current={active ? 'page' : undefined}
                  >
                    <Icon size={15} className="nav-item-icon" />
                    {!collapsed && (
                      <div style={{ minWidth: 0 }}>
                        <div style={{ lineHeight: 1.2, fontSize: '0.78rem' }}>{item.label}</div>
                        <div style={{ fontSize: '0.58rem', opacity: 0.45, marginTop: 1 }}>{item.sub}</div>
                      </div>
                    )}
                  </Link>
                );
              })}
            </div>
          ))}
        </div>

        {/* Footer status */}
        {!collapsed && (
          <div style={{
            padding: '0.875rem', borderTop: '1px solid rgba(255,255,255,0.08)',
            fontSize: '0.62rem', color: 'rgba(255,255,255,0.35)', flexShrink: 0,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#00A598', flexShrink: 0 }} />
              5T 誠信協議 Active
            </div>
          </div>
        )}
      </nav>

      {/* ── Main content ─────────────────────────── */}
      <main className={`main-area${collapsed ? ' expanded' : ''}`} id="main-content">
        {children}
      </main>

      {/* ── Mobile bottom nav ─────────────────────── */}
      <nav className="mobile-nav" aria-label="快速導航">
        <div className="mobile-nav-items">
          {mobileNavItems.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`mobile-nav-item${active ? ' active' : ''}`}
                aria-current={active ? 'page' : undefined}
              >
                <Icon size={20} />
                <span>{item.label}</span>
              </Link>
            );
          })}
          <button
            onClick={() => setMobileOpen(true)}
            className="mobile-nav-item"
            aria-label="更多"
            style={{ border: 'none', background: 'none', cursor: 'pointer' }}
          >
            <Menu size={20} />
            <span>更多</span>
          </button>
        </div>
      </nav>

      {/* ── Responsive overrides ─────────────────── */}
      <style>{`
        @media (min-width: 769px) {
          .mobile-close-btn { display: none !important; }
          .mobile-header { display: none !important; }
          .mobile-nav { display: none !important; }
          .mobile-overlay { display: none !important; }
          .desktop-collapse-btn { display: flex !important; }
        }
        @media (max-width: 768px) {
          .desktop-collapse-btn { display: none !important; }
          .mobile-close-btn { display: flex !important; }
          .mobile-header { display: flex !important; }
          .mobile-nav { display: block !important; }
          .sidebar-nav {
            transform: translateX(-100%);
            transition: transform 0.25s ease !important;
          }
          .sidebar-nav.mobile-open {
            transform: translateX(0) !important;
            box-shadow: 4px 0 24px rgba(0,0,0,0.3);
          }
          .main-area {
            margin-left: 0 !important;
            padding-top: calc(56px + 1rem) !important;
            padding-bottom: calc(64px + 1rem + env(safe-area-inset-bottom)) !important;
          }
        }
      `}</style>
    </div>
  );
}