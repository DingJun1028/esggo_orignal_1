'use client';
import { useState } from 'react';
import { FileText, CheckCircle, AlertTriangle, Zap } from 'lucide-react';

const chapters = [
  { id: 'general', label: '基礎治理', sub: 'General Disclosures', progress: 60, gri: 'GRI 2' },
  { id: 'env', label: '環境面', sub: 'Environment (E)', progress: 45, gri: 'GRI 302-306' },
  { id: 'social', label: '社會面', sub: 'Social (S)', progress: 30, gri: 'GRI 401-414' },
  { id: 'gov', label: '治理面', sub: 'Governance (G)', progress: 75, gri: 'GRI 205-207' },
];

const overall = Math.round(chapters.reduce((s, c) => s + c.progress, 0) / chapters.length);

export default function EditorPage() {
  const [activeChapter, setActiveChapter] = useState('general');
  const [content, setContent] = useState('本公司致力於推動永續發展，依據 GRI 2021 準則進行本年度永續報告書揭露。\n\n在環境管理方面，我們建立完整的溫室氣體盤查制度，並已取得 ISO 14064-1 第三方查證聲明書。');
  const [compliance] = useState(62);
  const chapter = chapters.find(c => c.id === activeChapter);

  return (
    <div className="fade-in" style={{ maxWidth: 1300 }}>
      <div className="page-header">
        <div className="page-eyebrow"><FileText size={12} /> SustainWrite · 5T Protocol · ZKP Seal</div>
        <h1 className="page-title">永續撰寫 SustainWrite Editor</h1>
        <div style={{ display: 'flex', gap: '2rem', marginTop: '0.75rem' }}>
          {[['208 頁', '總頁數'], ['34', '章節數'], [`${overall}%`, '完成度']].map(([v, l]) => (
            <div key={l}><div style={{ fontSize: '1.5rem', fontWeight: 900 }}>{v}</div><div style={{ fontSize: '0.7rem', opacity: 0.7 }}>{l}</div></div>
          ))}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr 280px', gap: '1rem' }}>
        {/* Chapter Nav */}
        <div className="card" style={{ padding: '1rem' }}>
          <div style={{ fontWeight: 800, fontSize: '0.8rem', marginBottom: '0.75rem', color: '#475569' }}>章節導覽</div>
          {chapters.map(ch => (
            <div key={ch.id} onClick={() => setActiveChapter(ch.id)}
              style={{
                padding: '0.75rem', borderRadius: 8, marginBottom: 4, cursor: 'pointer',
                background: activeChapter === ch.id ? '#003262' : 'transparent',
                color: activeChapter === ch.id ? 'white' : '#475569',
              }}>
              <div style={{ fontWeight: 700, fontSize: '0.82rem' }}>{ch.label}</div>
              <div style={{ fontSize: '0.65rem', opacity: 0.7, marginTop: 2 }}>{ch.gri}</div>
              <div style={{ height: 4, background: activeChapter === ch.id ? 'rgba(255,255,255,0.2)' : '#f1f5f9', borderRadius: 99, marginTop: 6 }}>
                <div style={{ height: '100%', width: `${ch.progress}%`, background: activeChapter === ch.id ? '#FDB515' : '#003262', borderRadius: 99 }} />
              </div>
            </div>
          ))}
        </div>

        {/* Editor */}
        <div className="card" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div style={{ fontWeight: 800, fontSize: '1rem' }}>{chapter?.label} — {chapter?.sub}</div>
          <textarea
            className="inp"
            style={{ flex: 1, minHeight: 400, resize: 'none', fontFamily: 'inherit', lineHeight: 1.8 }}
            value={content}
            onChange={e => setContent(e.target.value)}
            placeholder="請輸入本章節內容..."
          />
          <div style={{ display: 'flex', gap: '0.75rem' }}>
            <button className="btn btn-primary btn-sm"><Zap size={14} /> AI 自動生成草稿</button>
            <button className="btn btn-teal btn-sm"><CheckCircle size={14} /> 5T 封印</button>
            <button className="btn btn-ghost btn-sm">儲存版本</button>
          </div>
        </div>

        {/* Compliance Panel */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div className="card" style={{ padding: '1.5rem' }}>
            <div style={{ fontWeight: 800, fontSize: '0.85rem', marginBottom: '1rem' }}>合規掃描</div>
            <div style={{ textAlign: 'center', marginBottom: '1rem' }}>
              <div style={{ fontSize: '2.5rem', fontWeight: 900, color: compliance > 70 ? '#00A598' : '#FDB515' }}>{compliance}%</div>
              <div style={{ fontSize: '0.72rem', color: '#94a3b8' }}>GRI 合規率</div>
            </div>
            <div className="progress-track" style={{ marginBottom: '1rem' }}>
              <div className="progress-fill" style={{ width: `${compliance}%`, background: compliance > 70 ? '#00A598' : '#FDB515' }} />
            </div>
            {[
              { tag: 'GRI 2-1', status: 'pass', label: '組織基本資料揭露完整' },
              { tag: 'GRI 305-1', status: 'pass', label: '範疇一排放量已標記' },
              { tag: 'TCFD', status: 'warn', label: '建議加入氣候財務風險說明' },
              { tag: 'ISSB S2', status: 'warn', label: '建議加入碳強度指標' },
            ].map((item, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '0.5rem 0', borderBottom: '1px solid #f8fafc', fontSize: '0.73rem' }}>
                {item.status === 'pass' ? <CheckCircle size={13} color="#00A598" /> : <AlertTriangle size={13} color="#FDB515" />}
                <span className="badge badge-blue" style={{ fontSize: '0.55rem' }}>{item.tag}</span>
                <span style={{ color: '#475569', flex: 1 }}>{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}