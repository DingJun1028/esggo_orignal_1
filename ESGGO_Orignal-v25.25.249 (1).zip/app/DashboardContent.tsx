'use client';

import { useState, useEffect } from 'react';
import {
  Activity, Leaf, CheckCircle, TrendingUp, TrendingDown,
  Database, Route, Bot, FileText, Clock, ArrowRight, Heart
} from 'lucide-react';
import Link from 'next/link';

const kpis = [
  {
    label: 'ESG 合規率', value: '78%', trend: '+5%', up: true,
    color: '#003262', icon: <CheckCircle size={18} />,
    formula: '合規指標達成數 / 總指標數 × 100',
    detail: 'GRI 302, 303, 305, 401, 403 共 45 項指標，35 項達標',
  },
  {
    label: '碳排放量', value: '2,140', unit: 'tCO₂e', trend: '-12%', up: false,
    color: '#00A598', icon: <Leaf size={18} />,
    formula: '範疇一 + 範疇二 + 部分範疇三',
    detail: '範疇一: 850t | 範疇二: 890t | 範疇三(部分): 400t',
  },
  {
    label: '待辦任務', value: '12', trend: '3 逾期', up: false,
    color: '#FDB515', icon: <Activity size={18} />,
    formula: '跨部門 ESG 任務追蹤中',
    detail: '高優先: 4 | 中優先: 5 | 低優先: 3 | 逾期: 3',
  },
  {
    label: '5T 審計', value: '487', trend: '+28 本月', up: true,
    color: '#822980', icon: <Database size={18} />,
    formula: '所有 ESG 數據操作的不可篡改軌跡',
    detail: '新增: 312 | 修改: 98 | 驗證: 77',
  },
];

const modules = [
  { label: '環境 (E)', progress: 72, color: '#00A598', href: '/environmental', gri: 'GRI 302-306' },
  { label: '社會 (S)', progress: 65, color: '#3B7EA1', href: '/social', gri: 'GRI 401-414' },
  { label: '治理 (G)', progress: 80, color: '#003262', href: '/governance', gri: 'GRI 2, 205' },
  { label: '永續撰寫', progress: 45, color: '#FDB515', href: '/editor', gri: '報告書草稿' },
  { label: '實證金庫', progress: 60, color: '#822980', href: '/vault', gri: '5T 佐證' },
];

const activities = [
  { action: '提交 GRI 305-1 碳排數據', actor: '環安衛主任', time: '5m', tag: 'T1', color: '#00A598' },
  { action: 'VerifyLink™ ZKP 驗算完成', actor: '系統自動', time: '23m', tag: 'T4', color: '#003262' },
  { action: '更新供應商 ESG 評分', actor: '採購部門', time: '1h', tag: 'T5', color: '#3B7EA1' },
  { action: '偵測潛在綠漂風險 (低)', actor: 'AI 合規守衛', time: '2h', tag: 'T2', color: '#FDB515' },
  { action: '新增 GRI 401-1 員工數據', actor: '人資部門', time: '3h', tag: 'T1', color: '#822980' },
];

const quickActions = [
  { label: '新增環境數據', href: '/environmental', icon: <Leaf size={14} />, color: '#00A598' },
  { label: '撰寫報告章節', href: '/editor', icon: <FileText size={14} />, color: '#003262' },
  { label: 'AI 諮詢', href: '/advisory', icon: <Bot size={14} />, color: '#822980' },
  { label: '上傳佐證', href: '/vault', icon: <Database size={14} />, color: '#3B7EA1' },
  { label: '查看路線圖', href: '/roadmap', icon: <Route size={14} />, color: '#FDB515' },
  { label: '企業健檢', href: '/health-check', icon: <Heart size={14} />, color: '#ED4E33' },
];

export default function DashboardContent() {
  const [activeKpi, setActiveKpi] = useState<number | null>(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => { setMounted(true); }, []);
  if (!mounted) return null;

  return (
    <div className="fade-in" style={{ maxWidth: 1400 }}>
      {/* Header */}
      <div className="page-header">
        <div className="page-eyebrow">ESG GO 善向永續 · 5T 誠信協議 Active</div>
        <h1 className="page-title">永續治理控制台</h1>
        <p className="page-sub">臺北市中小企業永續治理實證系統 v8.5.0-Alpha</p>
      </div>

      {/* KPI Grid — 4 cols → 2 cols on tablet → 2 cols on mobile */}
      <div className="g-4" style={{ marginBottom: '1.5rem' }}>
        {kpis.map((kpi, i) => (
          <div
            key={i}
            className="card card-hover kpi-card"
            onClick={() => setActiveKpi(activeKpi === i ? null : i)}
            style={{ borderTop: `3px solid ${kpi.color}` }}
            role="button"
            tabIndex={0}
            aria-expanded={activeKpi === i}
            onKeyDown={e => e.key === 'Enter' && setActiveKpi(activeKpi === i ? null : i)}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.75rem' }}>
              <div className="kpi-label">{kpi.label}</div>
              <div style={{ color: kpi.color, opacity: 0.7, flexShrink: 0 }}>{kpi.icon}</div>
            </div>
            <div className="kpi-value" style={{ color: kpi.color }}>
              {kpi.value}
              {kpi.unit && <span style={{ fontSize: '0.8rem', fontWeight: 400, color: '#94a3b8', marginLeft: 3 }}>{kpi.unit}</span>}
            </div>
            <div className={`kpi-trend ${kpi.up ? 'up' : 'down'}`}>
              {kpi.up ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
              {kpi.trend}
            </div>
            {activeKpi === i && (
              <div style={{ marginTop: '0.875rem', paddingTop: '0.875rem', borderTop: '1px solid #f1f5f9', fontSize: '0.72rem', color: '#475569' }}>
                <div style={{ fontWeight: 700, marginBottom: '0.25rem', color: '#003262', fontSize: '0.7rem' }}>計算公式</div>
                <div style={{ marginBottom: '0.5rem', fontFamily: 'monospace', background: '#f8fafc', padding: '0.375rem 0.5rem', borderRadius: 4, fontSize: '0.68rem' }}>{kpi.formula}</div>
                <div style={{ fontWeight: 700, marginBottom: '0.25rem', color: '#003262', fontSize: '0.7rem' }}>細項說明</div>
                <div style={{ fontSize: '0.68rem' }}>{kpi.detail}</div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Middle row: Module Progress + Quick Actions */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: '1.25rem', marginBottom: '1.25rem' }}>
        {/* Module Progress */}
        <div className="card" style={{ padding: '1.25rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.125rem', flexWrap: 'wrap', gap: '0.5rem' }}>
            <h3 style={{ fontWeight: 800, fontSize: '0.95rem' }}>模組完成進度</h3>
            <span className="badge badge-blue">GRI 2021</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
            {modules.map((m, i) => (
              <Link key={i} href={m.href} style={{ textDecoration: 'none' }} aria-label={`${m.label} - ${m.progress}% 完成`}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.875rem' }}>
                  <div style={{ fontSize: '0.78rem', fontWeight: 600, width: 80, color: '#1e293b', flexShrink: 0 }}>{m.label}</div>
                  <div className="progress-track" style={{ flex: 1, minWidth: 0 }}>
                    <div className="progress-fill" style={{ width: `${m.progress}%`, background: m.color }} />
                  </div>
                  <div style={{ fontSize: '0.72rem', fontWeight: 700, width: 36, textAlign: 'right', color: m.color, flexShrink: 0 }}>{m.progress}%</div>
                  <span className="badge badge-gray" style={{ fontSize: '0.55rem', display: 'none' }} aria-hidden="true">{m.gri}</span>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="card" style={{ padding: '1.25rem' }}>
          <h3 style={{ fontWeight: 800, fontSize: '0.95rem', marginBottom: '1.125rem' }}>快速操作</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.625rem' }}>
            {quickActions.map((a, i) => (
              <Link key={i} href={a.href} style={{ textDecoration: 'none' }} aria-label={a.label}>
                <div className="card card-hover" style={{
                  padding: '0.875rem 0.75rem',
                  display: 'flex', flexDirection: 'column', gap: '0.4rem',
                  borderLeft: `3px solid ${a.color}`,
                }}>
                  <div style={{ color: a.color }}>{a.icon}</div>
                  <div style={{ fontSize: '0.7rem', fontWeight: 700, color: '#1e293b', lineHeight: 1.3 }}>{a.label}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* Activity Log */}
      <div className="card" style={{ padding: '1.25rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.125rem', flexWrap: 'wrap', gap: '0.5rem' }}>
          <h3 style={{ fontWeight: 800, fontSize: '0.95rem' }}>5T 實證活動日誌</h3>
          <Link href="/audit-log" className="btn btn-ghost btn-sm">
            查看完整 <ArrowRight size={13} />
          </Link>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.625rem' }}>
          {activities.map((a, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '0.875rem', padding: '0.625rem 0.75rem', background: '#fafbfc', borderRadius: 8 }}>
              <div style={{
                width: 30, height: 30, borderRadius: 6, flexShrink: 0,
                background: `${a.color}15`, color: a.color,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: '0.58rem', fontWeight: 800, letterSpacing: '0.02em',
              }} aria-label={`5T 標籤 ${a.tag}`}>{a.tag}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: '0.8rem', fontWeight: 600, white: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{a.action}</div>
                <div style={{ fontSize: '0.67rem', color: '#94a3b8', marginTop: 1 }}>{a.actor}</div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 3, fontSize: '0.67rem', color: '#94a3b8', flexShrink: 0 }}>
                <Clock size={10} aria-hidden="true" /> {a.time} ago
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* RWD: stack the middle row on tablet/mobile */}
      <style>{`
        @media (max-width: 900px) {
          div[style*="gridTemplateColumns: 1fr 320px"] {
            grid-template-columns: 1fr !important;
          }
        }
        @media (max-width: 768px) {
          .g-4 { grid-template-columns: repeat(2, 1fr) !important; }
        }
        @media (max-width: 400px) {
          .g-4 { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </div>
  );
}