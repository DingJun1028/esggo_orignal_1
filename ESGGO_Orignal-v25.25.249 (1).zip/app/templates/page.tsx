'use client';
import { BookOpen, ArrowRight } from 'lucide-react';
import Link from 'next/link';

const templates = [
  { title: 'GHG 溫室氣體盤查', gri: 'GRI 305-1/2/3', fields: 12, docs: 5, href: '/editor' },
  { title: '能源管理揭露', gri: 'GRI 302-1/4', fields: 8, docs: 3, href: '/editor' },
  { title: '水資源管理', gri: 'GRI 303-1/3', fields: 6, docs: 4, href: '/editor' },
  { title: '廢棄物管理', gri: 'GRI 306-3/4/5', fields: 7, docs: 3, href: '/editor' },
  { title: '員工結構與流動', gri: 'GRI 401-1', fields: 10, docs: 2, href: '/editor' },
  { title: '職業安全衛生', gri: 'GRI 403-1/2', fields: 9, docs: 4, href: '/editor' },
  { title: '董事會治理結構', gri: 'GRI 2-9/10', fields: 8, docs: 3, href: '/editor' },
  { title: '重大性評估', gri: 'GRI 3-1/2/3', fields: 15, docs: 5, href: '/materiality' },
];

export default function TemplatesPage() {
  return (
    <div className="fade-in" style={{ maxWidth: 1100 }}>
      <div className="page-header">
        <div className="page-eyebrow"><BookOpen size={12} /> GRI 2021 · SASB · TCFD 全套框架</div>
        <h1 className="page-title">專家零算力模板 Templates</h1>
        <p className="page-sub">一鍵套用 GRI/SASB/TCFD 標準模板 · 整合永續撰寫工作台</p>
      </div>

      <div className="g-auto">
        {templates.map((t, i) => (
          <Link key={i} href={t.href} style={{ textDecoration: 'none' }}>
            <div className="card card-hover" style={{ padding: '1.5rem', height: '100%', borderTop: '3px solid #003262' }}>
              <div style={{ fontWeight: 800, fontSize: '0.95rem', marginBottom: '0.5rem' }}>{t.title}</div>
              <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1rem' }}>
                <span className="badge badge-blue">{t.gri}</span>
              </div>
              <div style={{ display: 'flex', gap: '1rem', fontSize: '0.72rem', color: '#94a3b8', marginBottom: '1rem' }}>
                <span>📊 {t.fields} 個欄位</span>
                <span>📄 {t.docs} 份佐證</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 4, color: '#003262', fontSize: '0.8rem', fontWeight: 700 }}>
                套用模板 <ArrowRight size={14} />
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}