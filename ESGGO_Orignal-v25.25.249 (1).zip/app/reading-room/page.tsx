'use client';
import { useState } from 'react';
import { Library, ExternalLink, Clock } from 'lucide-react';

const regulations = [
  { title: '金管會上市櫃 ESG 揭露規範 2025', country: '台灣', year: 2025, framework: 'GRI 2021', url: 'https://www.fsc.gov.tw', type: 'regulation' },
  { title: 'EU CSRD 企業永續報告指令', country: '歐盟', year: 2024, framework: 'ESRS', url: 'https://ec.europa.eu', type: 'regulation' },
  { title: 'ISSB S1/S2 國際永續揭露標準', country: '國際', year: 2023, framework: 'ISSB', url: 'https://www.ifrs.org', type: 'standard' },
  { title: 'ISSA 5000 永續確信標準', country: '國際', year: 2024, framework: 'IAASB', url: 'https://www.iaasb.org', type: 'standard' },
];

const benchmarks = [
  { company: '台積電', industry: '半導體', year: 2023, score: 95, url: 'https://sustainability.tsmc.com' },
  { company: '台達電', industry: '電子製造', year: 2023, score: 92, url: 'https://www.deltaww.com' },
  { company: '聯合再生能源', industry: '再生能源', year: 2023, score: 88, url: 'https://www.urecoenergy.com' },
];

export default function ReadingRoomPage() {
  const [tab, setTab] = useState<'regulations' | 'benchmarks'>('regulations');

  return (
    <div className="fade-in" style={{ maxWidth: 1100 }}>
      <div className="page-header">
        <div className="page-eyebrow"><Library size={12} /> 法規庫 · 台灣年鑑 · 標竿報告</div>
        <h1 className="page-title">永續閱覽室 Reading Room</h1>
        <p className="page-sub">ESG 法規情報 · 台灣 ESG 年鑑 · 產業標竿報告書</p>
      </div>

      <div className="tabs" style={{ marginBottom: '1rem' }}>
        <button className={`tab ${tab === 'regulations' ? 'active' : ''}`} onClick={() => setTab('regulations')}>📋 法規與標準</button>
        <button className={`tab ${tab === 'benchmarks' ? 'active' : ''}`} onClick={() => setTab('benchmarks')}>🏆 標竿企業報告</button>
      </div>

      {tab === 'regulations' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {regulations.map((r, i) => (
            <div key={i} className="card" style={{ padding: '1.25rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '1rem' }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: '0.9rem', marginBottom: 4 }}>{r.title}</div>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <span className="badge badge-blue">{r.framework}</span>
                  <span className="badge badge-gray">{r.country}</span>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: '0.7rem', color: '#94a3b8' }}><Clock size={11} /> {r.year}</span>
                </div>
              </div>
              <a href={r.url} target="_blank" rel="noreferrer" className="btn btn-ghost btn-sm">
                查看原文 <ExternalLink size={12} />
              </a>
            </div>
          ))}
        </div>
      )}

      {tab === 'benchmarks' && (
        <div className="card">
          <div className="tbl-wrap">
            <table className="tbl">
              <thead><tr><th>企業</th><th>產業</th><th>年度</th><th>ESG 評分</th><th>報告書</th></tr></thead>
              <tbody>
                {benchmarks.map((b, i) => (
                  <tr key={i}>
                    <td style={{ fontWeight: 700 }}>{b.company}</td>
                    <td><span className="badge badge-gray">{b.industry}</span></td>
                    <td style={{ color: '#94a3b8' }}>{b.year}</td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div className="progress-track" style={{ width: 80 }}>
                          <div className="progress-fill" style={{ width: `${b.score}%`, background: '#003262' }} />
                        </div>
                        <span style={{ fontWeight: 700, color: '#003262' }}>{b.score}</span>
                      </div>
                    </td>
                    <td>
                      <a href={b.url} target="_blank" rel="noreferrer" className="btn btn-ghost btn-xs">
                        <ExternalLink size={12} /> 查看
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}