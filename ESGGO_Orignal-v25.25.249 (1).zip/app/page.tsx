import { Suspense } from "react";
import DashboardContent from "./DashboardContent";

export default function HomePage() {
  return (
    <Suspense fallback={
      <div style={{ padding: '2rem' }}>
        <div style={{ height: 160, borderRadius: 16, background: 'linear-gradient(135deg, #003262, #3B7EA1)', marginBottom: '1.5rem' }} />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '1rem', marginBottom: '1.5rem' }}>
          {[1,2,3,4].map(i => <div key={i} style={{ height: 110, background: 'white', borderRadius: 12, border: '1px solid #e2e8f0' }} />)}
        </div>
        <div style={{ height: 300, background: 'white', borderRadius: 12, border: '1px solid #e2e8f0' }} />
      </div>
    }>
      <DashboardContent />
    </Suspense>
  );
}