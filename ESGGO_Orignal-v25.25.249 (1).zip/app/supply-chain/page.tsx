'use client';
import { Truck } from 'lucide-react';

const suppliers = [
  { name: '台灣綠色科技', type: '電子零件', esg: 88, risk: 'low', local: true, pledge: true },
  { name: '新竹材料', type: '原物料', esg: 72, risk: 'medium', local: true, pledge: true },
  { name: 'Vietnam Parts Co.', type: '電子零件', esg: 55, risk: 'high', local: false, pledge: false },
  { name: '高雄化工', type: '化學品', esg: 81, risk: 'low', local: true, pledge: true },
  { name: 'Malaysia Mfg.', type: '製造', esg: 64, risk: 'medium', local: false, pledge: false },
];

const riskColors: Record<string, string> = { low: '#00A598', medium: '#FDB515', high: '#ED4E33' };

export default function SupplyChainPage() {
  return (
    <div className="fade-in" style={{ maxWidth: 1100 }}>
      <div className="page-header">
        <div className="page-eyebrow"><Truck size={12} /> GRI 308 · GRI 414 · 供應鏈透明</div>
        <h1 className="page-title">供應鏈透明 Supply Chain</h1>
        <p className="page-sub">供應商 ESG 評分 · 風險分級 · 永續採購</p>
      </div>

      <div className="g-4" style={{ marginBottom: '1.5rem' }}>
        {[
          { label: '供應商總數', value: String(suppliers.length), color: '#003262' },
          { label: '本地採購比', value: `${Math.round(suppliers.filter(s => s.local).length / suppliers.length * 100)}%`, color: '#00A598' },
          { label: '簽署承諾書', value: `${suppliers.filter(s => s.pledge).length}/${suppliers.length}`, color: '#FDB515' },
          { label: '高風險供應商', value: String(suppliers.filter(s => s.risk === 'high').length), color: '#ED4E33' },
        ].map((s, i) => (
          <div key={i} className="card kpi-card" style={{ borderTop: `3px solid ${s.color}` }}>
            <div className="kpi-label">{s.label}</div>
            <div className="kpi-value" style={{ color: s.color }}>{s.value}</div>
          </div>
        ))}
      </div>

      <div className="card">
        <div className="tbl-wrap">
          <table className="tbl">
            <thead><tr><th>供應商</th><th>類型</th><th>ESG 評分</th><th>風險</th><th>本地</th><th>承諾書</th></tr></thead>
            <tbody>
              {suppliers.map((s, i) => (
                <tr key={i}>
                  <td style={{ fontWeight: 700 }}>{s.name}</td>
                  <td><span className="badge badge-gray">{s.type}</span></td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div className="progress-track" style={{ width: 80 }}>
                        <div className="progress-fill" style={{ width: `${s.esg}%`, background: s.esg > 75 ? '#00A598' : '#FDB515' }} />
                      </div>
                      <span style={{ fontWeight: 700 }}>{s.esg}</span>
                    </div>
                  </td>
                  <td><span className="badge" style={{ background: `${riskColors[s.risk]}15`, color: riskColors[s.risk] }}>{s.risk}</span></td>
                  <td>{s.local ? '✅' : '❌'}</td>
                  <td>{s.pledge ? '✅' : '❌'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}