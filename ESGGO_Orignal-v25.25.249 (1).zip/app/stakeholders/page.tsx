'use client';
import { UserCheck } from 'lucide-react';

const stakeholders = [
  { name: '投資人', concern: '財務表現 & ESG 評分', influence: 95, engagement: 'quarterly', sentiment: 'positive' },
  { name: '員工', concern: '薪酬福利 & 職場安全', influence: 80, engagement: 'ongoing', sentiment: 'neutral' },
  { name: '客戶', concern: '產品品質 & 碳足跡', influence: 85, engagement: 'ongoing', sentiment: 'positive' },
  { name: '供應商', concern: '採購公平性 & 永續要求', influence: 65, engagement: 'annual', sentiment: 'neutral' },
  { name: '主管機關', concern: '合規揭露 & 法遵', influence: 90, engagement: 'regulatory', sentiment: 'positive' },
  { name: '社區', concern: '環境影響 & 就業機會', influence: 60, engagement: 'ad-hoc', sentiment: 'positive' },
];

const sentimentColors: Record<string, string> = { positive: '#00A598', neutral: '#FDB515', negative: '#ED4E33' };

export default function StakeholdersPage() {
  return (
    <div className="fade-in" style={{ maxWidth: 1100 }}>
      <div className="page-header">
        <div className="page-eyebrow"><UserCheck size={12} /> GRI 2-29 · 利害關係人參與</div>
        <h1 className="page-title">利害關係人 Stakeholders</h1>
        <p className="page-sub">影響力評估 · 關注議題 · 參與頻率 · 情感追蹤</p>
      </div>

      <div className="card">
        <div className="tbl-wrap">
          <table className="tbl">
            <thead><tr><th>利害關係人</th><th>主要關注</th><th>影響力</th><th>參與頻率</th><th>情感</th></tr></thead>
            <tbody>
              {stakeholders.map((s, i) => (
                <tr key={i}>
                  <td style={{ fontWeight: 700 }}>{s.name}</td>
                  <td style={{ fontSize: '0.8rem', color: '#475569' }}>{s.concern}</td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div className="progress-track" style={{ width: 80 }}>
                        <div className="progress-fill" style={{ width: `${s.influence}%`, background: '#003262' }} />
                      </div>
                      <span style={{ fontWeight: 700 }}>{s.influence}%</span>
                    </div>
                  </td>
                  <td><span className="badge badge-gray">{s.engagement}</span></td>
                  <td><span className="badge" style={{ background: `${sentimentColors[s.sentiment]}15`, color: sentimentColors[s.sentiment] }}>{s.sentiment}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}