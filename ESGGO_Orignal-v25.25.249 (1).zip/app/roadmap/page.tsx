'use client';
import { Route, CheckCircle, Clock, AlertCircle } from 'lucide-react';

const milestones = [
  { title: '完成基準年碳盤查', year: 2024, status: 'achieved', category: 'Carbon', value: '2,140 tCO₂e', gri: 'GRI 305-1', sbti: false },
  { title: '導入可再生能源 20%', year: 2025, status: 'in_progress', category: 'Energy', value: '目標: 20%', gri: 'GRI 302-1', sbti: false },
  { title: '提交 SBTi 科學基礎目標', year: 2025, status: 'planned', category: 'Strategy', value: '1.5°C 路徑', gri: 'GRI 305-4', sbti: true },
  { title: '範疇一減碳 25%', year: 2027, status: 'planned', category: 'Carbon', value: '-25% vs 2024', gri: 'GRI 305-1', sbti: true },
  { title: '達成 SBTi 1.5°C 中期目標', year: 2030, status: 'planned', category: 'Strategy', value: '-46% 減碳', gri: 'GRI 305-1', sbti: true },
  { title: '淨零碳排放', year: 2050, status: 'planned', category: 'Strategy', value: 'Net Zero', gri: 'GRI 305', sbti: true },
];

const statusIcons: Record<string, React.ReactNode> = {
  achieved: <CheckCircle size={16} color="#00A598" />,
  in_progress: <Clock size={16} color="#FDB515" />,
  planned: <AlertCircle size={16} color="#94a3b8" />,
};

export default function RoadmapPage() {
  return (
    <div className="fade-in" style={{ maxWidth: 1000 }}>
      <div className="page-header">
        <div className="page-eyebrow"><Route size={12} /> SBTi · GRI 305 · 淨零路徑</div>
        <h1 className="page-title">淨零路線圖 Net-Zero Roadmap</h1>
        <p className="page-sub">科學基礎減碳目標 (SBTi) · 2050 淨零碳排</p>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', position: 'relative' }}>
        <div style={{ position: 'absolute', left: 32, top: 0, bottom: 0, width: 2, background: '#e2e8f0', zIndex: 0 }} />
        {milestones.map((m, i) => (
          <div key={i} style={{ display: 'flex', gap: '1.5rem', alignItems: 'flex-start', position: 'relative', zIndex: 1 }}>
            <div style={{
              width: 48, height: 48, borderRadius: '50%', background: m.status === 'achieved' ? '#00A598' : m.status === 'in_progress' ? '#FDB515' : 'white',
              border: '3px solid', borderColor: m.status === 'achieved' ? '#00A598' : m.status === 'in_progress' ? '#FDB515' : '#e2e8f0',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, color: 'white', fontWeight: 800, fontSize: '0.75rem',
            }}>
              {m.status === 'achieved' ? <CheckCircle size={20} /> : <span style={{ color: m.status === 'planned' ? '#94a3b8' : '#003262' }}>{m.year}</span>}
            </div>
            <div className="card" style={{ flex: 1, padding: '1.25rem', borderLeft: m.sbti ? '3px solid #003262' : '3px solid #f1f5f9' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h3 style={{ fontWeight: 700, fontSize: '0.95rem' }}>{m.title}</h3>
                <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                  {m.sbti && <span className="badge badge-blue">SBTi</span>}
                  <span className="badge badge-gray">{m.year}</span>
                </div>
              </div>
              <div style={{ color: '#94a3b8', fontSize: '0.78rem', marginTop: 4 }}>{m.value} · {m.gri}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}