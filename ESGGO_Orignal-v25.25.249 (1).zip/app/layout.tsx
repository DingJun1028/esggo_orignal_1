import type { Metadata } from "next";
import "./globals.css";
import { Suspense } from "react";
import ClientLayout from "./ClientLayout";

export const metadata: Metadata = {
  title: "ESG GO 善向永續",
  description: "臺北市中小企業永續治理實證系統 v8.5.0-Alpha",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="zh-TW">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
      </head>
      <body>
        <Suspense fallback={
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            minHeight: '100vh', background: '#f5f7fa',
            fontFamily: 'Inter, -apple-system, sans-serif',
          }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>🌿</div>
              <div style={{ color: '#003262', fontWeight: 800, fontSize: '1.1rem' }}>ESG GO 善向永續</div>
              <div style={{ color: '#94a3b8', fontSize: '0.8rem', marginTop: '0.5rem' }}>系統載入中...</div>
            </div>
          </div>
        }>
          <ClientLayout>
            <Suspense fallback={null}>
              {children}
            </Suspense>
          </ClientLayout>
        </Suspense>
      </body>
    </html>
  );
}