'use client';
import { BookOpen, ExternalLink } from 'lucide-react';

const standards = [
  { name: 'GRI 2021', desc: 'Global Reporting Initiative 全套揭露框架', relevance: 98, url: 'https://www.globalreporting.org', tags: ['E', 'S', 'G'] },
  { name: 'ISSB S1/S2', desc: 'IFRS 永續相關財務揭露標準', relevance: 92, url: 'https://www.ifrs.org', tags: ['氣候', '財務'] },
  { name: 'TCFD', desc: '氣候相關財務揭露工作小組建議', relevance: 88, url: 'https://www.fsb-tcfd.org', tags: ['氣候', '財務'] },
  { name: 'SASB', desc: '永續會計準則委員會產業標準', relevance: 82, url: 'https://www.sasb.org', tags: ['產業', '會計'] },
  { name: 'ISO 14064-1', desc: '溫室氣體盤查與查驗標準', relevance: 90, url: 'https://www.iso.org', tags: ['GHG', 'E'] },
  { name: 'ISSA 5000', desc: '永續確信國際標準', relevance: 78, url: 'https://www.iaasb.org', tags: ['確信', '查證'] },
];

export default function LibraryPage() {
  return (
    <div className="fade-in" style={{ maxWidth: 1000 }}>
      <div className="page-header">
        <div className="page-eyebrow"><BookOpen size={12} /> 國際標準索引 · 法規文庫</div>
        <h1 className="page-title">永續智庫 SustainLibrary</h1>
        <p className="page-sub">GRI · ISSB · TCFD · SASB · ISO 標準文檔</p>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
        {standards.map((s, i) => (
          <div key={i} className="card" style={{ padding: '1.25rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '1rem' }}>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.5rem' }}>
                <div style={{ fontWeight: 800, fontSize: '1rem', color: '#003262' }}>{s.name}</div>
                {s.tags.map(t => <span key={t} className="badge badge-blue" style={{ fontSize: '0.6rem' }}>{t}</span>)}
              </div>
              <div style={{ fontSize: '0.83rem', color: '#475569' }}>{s.desc}</div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', flexShrink: 0 }}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontWeight: 800, color: '#003262' }}>{s.relevance}%</div>
                <div style={{ fontSize: '0.6rem', color: '#94a3b8' }}>相關度</div>
              </div>
              <a href={s.url} target="_blank" rel="noreferrer" className="btn btn-ghost btn-sm">
                <ExternalLink size={12} /> 查看
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}