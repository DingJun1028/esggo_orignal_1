'use client';
import { useState } from 'react';
import { Leaf, CheckCircle, Edit2, Save, Plus } from 'lucide-react';

const initialMetrics = [
  { id: 1, category: 'GHG', name: '範疇一直接排放', value: 850, unit: 'tCO₂e', gri: 'GRI 305-1', verified: true },
  { id: 2, category: 'GHG', name: '範疇二間接排放', value: 890, unit: 'tCO₂e', gri: 'GRI 305-2', verified: true },
  { id: 3, category: 'Energy', name: '總用電量', value: 4500, unit: 'MWh', gri: 'GRI 302-1', verified: true },
  { id: 4, category: 'Energy', name: '再生能源比例', value: 38, unit: '%', gri: 'GRI 302-1', verified: false },
  { id: 5, category: 'Water', name: '總取水量', value: 12500, unit: 'm³', gri: 'GRI 303-3', verified: false },
  { id: 6, category: 'Waste', name: '有害廢棄物', value: 45, unit: 'ton', gri: 'GRI 306-3', verified: false },
];

const categories = ['全部', 'GHG', 'Energy', 'Water', 'Waste'];
const catColors: Record<string, string> = { GHG: '#003262', Energy: '#FDB515', Water: '#3B7EA1', Waste: '#822980' };

export default function EnvironmentalPage() {
  const [metrics, setMetrics] = useState(initialMetrics);
  const [filter, setFilter] = useState('全部');
  const [editId, setEditId] = useState<number | null>(null);
  const [editValue, setEditValue] = useState('');

  const filtered = filter === '全部' ? metrics : metrics.filter(m => m.category === filter);
  const verified = metrics.filter(m => m.verified).length;

  const saveEdit = (id: number) => {
    setMetrics(prev => prev.map(m => m.id === id ? { ...m, value: parseFloat(editValue) || m.value } : m));
    setEditId(null);
  };

  return (
    <div className="fade-in" style={{ maxWidth: 1200 }}>
      <div className="page-header">
        <div className="page-eyebrow"><Leaf size={12} /> GRI 302-306 · ISO 14064-1</div>
        <h1 className="page-title">環境指揮中心</h1>
        <p className="page-sub">溫室氣體 · 能源管理 · 水資源 · 廢棄物</p>
      </div>

      <div className="g-4" style={{ marginBottom: '1.25rem' }}>
        {[
          { label: 'GHG 排放', value: '1,740', unit: 'tCO₂e', color: '#003262' },
          { label: '能源使用', value: '4,500', unit: 'MWh', color: '#FDB515' },
          { label: '水資源', value: '12,500', unit: 'm³', color: '#3B7EA1' },
          { label: '資料驗證', value: `${verified}/${metrics.length}`, unit: '已驗證', color: '#00A598' },
        ].map((s, i) => (
          <div key={i} className="card kpi-card" style={{ borderTop: `3px solid ${s.color}` }}>
            <div className="kpi-label">{s.label}</div>
            <div className="kpi-value" style={{ color: s.color }}>{s.value}</div>
            <div style={{ fontSize: '0.7rem', color: '#94a3b8' }}>{s.unit}</div>
          </div>
        ))}
      </div>

      {/* Filter pills — scrollable on mobile */}
      <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1rem', overflowX: 'auto', paddingBottom: '4px', flexWrap: 'wrap' }}>
        {categories.map(c => (
          <button key={c} onClick={() => setFilter(c)} style={{
            padding: '0.375rem 0.875rem', borderRadius: 99, border: 'none', cursor: 'pointer',
            fontSize: '0.78rem', fontWeight: 600, flexShrink: 0,
            background: filter === c ? '#003262' : 'white', color: filter === c ? 'white' : '#475569',
            boxShadow: '0 1px 3px rgba(0,0,0,0.06)',
          }}>{c}</button>
        ))}
      </div>

      <div className="card">
        <div className="tbl-wrap">
          <table className="tbl">
            <thead>
              <tr>
                <th>類別</th><th>指標名稱</th><th>數值</th><th>單位</th>
                <th>GRI</th><th>狀態</th><th>操作</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(m => (
                <tr key={m.id}>
                  <td>
                    <span className="badge" style={{ background: `${catColors[m.category]}15`, color: catColors[m.category] }}>
                      {m.category}
                    </span>
                  </td>
                  <td style={{ fontWeight: 600 }}>{m.name}</td>
                  <td>
                    {editId === m.id ? (
                      <input className="inp" style={{ width: 90, padding: '0.3rem 0.5rem', fontSize: '0.83rem' }}
                        value={editValue} onChange={e => setEditValue(e.target.value)} autoFocus />
                    ) : (
                      <span style={{ fontWeight: 700, fontFamily: 'monospace' }}>{m.value.toLocaleString()}</span>
                    )}
                  </td>
                  <td style={{ color: '#94a3b8' }}>{m.unit}</td>
                  <td><span className="badge badge-blue">{m.gri}</span></td>
                  <td>
                    {m.verified
                      ? <span style={{ display: 'flex', alignItems: 'center', gap: 4, color: '#00A598', fontSize: '0.72rem', fontWeight: 700 }}><CheckCircle size={12} />已驗證</span>
                      : <span className="badge badge-gray">待驗</span>
                    }
                  </td>
                  <td>
                    {editId === m.id ? (
                      <button className="btn btn-teal btn-xs" onClick={() => saveEdit(m.id)}><Save size={11} /> 儲存</button>
                    ) : (
                      <button className="btn btn-ghost btn-xs" onClick={() => { setEditId(m.id); setEditValue(String(m.value)); }}>
                        <Edit2 size={11} /> 編輯
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}