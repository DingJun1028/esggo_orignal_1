'use client';
import { useState } from 'react';
import { Send, CheckCircle, Clock, Shield } from 'lucide-react';

const reports = [
  { title: '2023 永續報告書', year: 2023, framework: ['GRI 2021', 'TCFD', 'SASB'], status: 'published', pages: 156, gri: 78, zkp: true, hash: 'sha256:a1b2c3...' },
  { title: '2024 永續報告書', year: 2024, framework: ['GRI 2021', 'ISSB S1/S2', 'TCFD'], status: 'reviewing', pages: 0, gri: 62, zkp: false, hash: '' },
];

export default function PublishPage() {
  const [selected, setSelected] = useState(0);
  const report = reports[selected];

  return (
    <div className="fade-in" style={{ maxWidth: 1100 }}>
      <div className="page-header">
        <div className="page-eyebrow"><Send size={12} /> 報告發布 · ZKP 認證</div>
        <h1 className="page-title">報告發布 Publish</h1>
        <p className="page-sub">永續報告書生成 · 5T 完整性封印 · ZKP 零知識認證</p>
      </div>

      <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1.5rem' }}>
        {reports.map((r, i) => (
          <div key={i} className="card card-hover" style={{ padding: '1rem 1.5rem', cursor: 'pointer', border: selected === i ? '2px solid #003262' : '2px solid transparent' }}
            onClick={() => setSelected(i)}>
            <div style={{ fontWeight: 700 }}>{r.title}</div>
            <div style={{ fontSize: '0.72rem', color: '#94a3b8', marginTop: 4 }}>
              {r.status === 'published' ? '✅ 已發布' : '🔄 審查中'} · GRI {r.gri}%
            </div>
          </div>
        ))}
      </div>

      <div className="g-2">
        <div className="card" style={{ padding: '2rem' }}>
          <h3 style={{ fontWeight: 800, fontSize: '1.1rem', marginBottom: '1.5rem' }}>報告書資訊</h3>
          {[
            ['報告標題', report.title], ['報告年度', String(report.year)],
            ['框架', report.framework.join(', ')], ['GRI 覆蓋率', `${report.gri}%`],
            ['狀態', report.status === 'published' ? '已發布' : '審查中'],
          ].map(([label, value]) => (
            <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '0.875rem 0', borderBottom: '1px solid #f8fafc' }}>
              <span style={{ color: '#94a3b8', fontSize: '0.83rem' }}>{label}</span>
              <span style={{ fontWeight: 600, fontSize: '0.83rem' }}>{value}</span>
            </div>
          ))}
        </div>

        <div className="card" style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <h3 style={{ fontWeight: 800, fontSize: '1.1rem' }}>5T 完整性封印</h3>
          {report.zkp ? (
            <div style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 10, padding: '1.5rem', textAlign: 'center' }}>
              <CheckCircle size={32} color="#00A598" style={{ margin: '0 auto 0.75rem' }} />
              <div style={{ fontWeight: 800, color: '#003262' }}>ZKP 驗算已完成</div>
              <code style={{ fontSize: '0.7rem', color: '#94a3b8', display: 'block', marginTop: '0.5rem' }}>{report.hash}</code>
            </div>
          ) : (
            <div style={{ background: '#fffbeb', border: '1px solid #fef08a', borderRadius: 10, padding: '1.5rem', textAlign: 'center' }}>
              <Clock size={32} color="#FDB515" style={{ margin: '0 auto 0.75rem' }} />
              <div style={{ fontWeight: 800, color: '#92400e' }}>等待 ZKP 驗算</div>
              <button className="btn btn-primary" style={{ marginTop: '1rem' }}>
                <Shield size={14} /> 啟動 ZKP 封印
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}