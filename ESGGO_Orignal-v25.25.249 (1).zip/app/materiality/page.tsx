'use client';
import { BarChart3 } from 'lucide-react';

const topics = [
  { name: '氣候變遷與碳管理', impact: 85, concern: 90, category: 'E' },
  { name: '能源效率', impact: 70, concern: 75, category: 'E' },
  { name: '水資源管理', impact: 65, concern: 60, category: 'E' },
  { name: '廢棄物管理', impact: 60, concern: 65, category: 'E' },
  { name: '員工安全衛生', impact: 80, concern: 85, category: 'S' },
  { name: '人才發展與培訓', impact: 75, concern: 80, category: 'S' },
  { name: '供應鏈管理', impact: 70, concern: 72, category: 'S' },
  { name: '董事會多元化', impact: 65, concern: 70, category: 'G' },
  { name: '反貪腐與商業誠信', impact: 85, concern: 80, category: 'G' },
];

const catColors: Record<string, string> = { E: '#00A598', S: '#3B7EA1', G: '#822980' };

export default function MaterialityPage() {
  return (
    <div className="fade-in" style={{ maxWidth: 1000 }}>
      <div className="page-header">
        <div className="page-eyebrow"><BarChart3 size={12} /> GRI 3-1~3-3 · 雙重重大性</div>
        <h1 className="page-title">重大性矩陣 Materiality</h1>
        <p className="page-sub">衝擊度 × 關注度評估 · 雙重重大性分析</p>
      </div>

      <div className="card" style={{ padding: '1.5rem' }}>
        <div className="tbl-wrap">
          <table className="tbl">
            <thead>
              <tr><th>ESG 議題</th><th>類別</th><th>衝擊度</th><th>關注度</th><th>重大性</th></tr>
            </thead>
            <tbody>
              {topics.sort((a, b) => (b.impact + b.concern) - (a.impact + a.concern)).map((t, i) => {
                const score = Math.round((t.impact + t.concern) / 2);
                return (
                  <tr key={i}>
                    <td style={{ fontWeight: 600 }}>{t.name}</td>
                    <td><span className="badge" style={{ background: `${catColors[t.category]}15`, color: catColors[t.category] }}>{t.category}</span></td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div className="progress-track" style={{ width: 80 }}>
                          <div className="progress-fill" style={{ width: `${t.impact}%`, background: catColors[t.category] }} />
                        </div>
                        <span style={{ fontSize: '0.75rem', fontWeight: 700 }}>{t.impact}%</span>
                      </div>
                    </td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div className="progress-track" style={{ width: 80 }}>
                          <div className="progress-fill" style={{ width: `${t.concern}%`, background: '#FDB515' }} />
                        </div>
                        <span style={{ fontSize: '0.75rem', fontWeight: 700 }}>{t.concern}%</span>
                      </div>
                    </td>
                    <td>
                      <span className="badge" style={{ background: score > 75 ? '#003262' : '#f1f5f9', color: score > 75 ? 'white' : '#94a3b8' }}>
                        {score > 75 ? '高' : score > 60 ? '中' : '低'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}