'use client';
import { Users, CheckCircle } from 'lucide-react';

const metrics = [
  { category: '勞工', name: '全職員工人數', value: 1250, unit: '人', gri: 'GRI 2-7', verified: true },
  { category: '勞工', name: '女性員工比例', value: 42, unit: '%', gri: 'GRI 405-1', verified: true },
  { category: '安全', name: '失能傷害頻率', value: 0.45, unit: '次/百萬工時', gri: 'GRI 403-2', verified: true },
  { category: '安全', name: '職業病發生率', value: 0, unit: '件', gri: 'GRI 403-10', verified: true },
  { category: '培訓', name: '平均受訓時數', value: 24, unit: '小時/人', gri: 'GRI 404-1', verified: false },
  { category: '供應鏈', name: '本地採購比例', value: 65, unit: '%', gri: 'GRI 204-1', verified: false },
];

const catColors: Record<string, string> = { '勞工': '#3B7EA1', '安全': '#ED4E33', '培訓': '#822980', '供應鏈': '#FDB515' };

export default function SocialPage() {
  return (
    <div className="fade-in" style={{ maxWidth: 1100 }}>
      <div className="page-header">
        <div className="page-eyebrow"><Users size={12} /> GRI 401-414 · 社會影響</div>
        <h1 className="page-title">社會影響中心</h1>
        <p className="page-sub">勞工權益 · 職業安全 · 人才培育 · 供應鏈</p>
      </div>
      <div className="g-4" style={{ marginBottom: '1.25rem' }}>
        {[
          { label: '員工人數', value: '1,250', unit: '人', color: '#3B7EA1' },
          { label: '女性比例', value: '42%', unit: '', color: '#822980' },
          { label: '傷害頻率', value: '0.45', unit: 'FR', color: '#ED4E33' },
          { label: '平均培訓', value: '24h', unit: '/人', color: '#FDB515' },
        ].map((s, i) => (
          <div key={i} className="card kpi-card" style={{ borderTop: `3px solid ${s.color}` }}>
            <div className="kpi-label">{s.label}</div>
            <div className="kpi-value" style={{ color: s.color }}>{s.value}</div>
            <div style={{ fontSize: '0.7rem', color: '#94a3b8' }}>{s.unit}</div>
          </div>
        ))}
      </div>
      <div className="card">
        <div className="tbl-wrap">
          <table className="tbl">
            <thead><tr><th>類別</th><th>指標</th><th>數值</th><th>GRI</th><th>驗證</th></tr></thead>
            <tbody>
              {metrics.map((m, i) => (
                <tr key={i}>
                  <td><span className="badge" style={{ background: `${catColors[m.category]}15`, color: catColors[m.category] }}>{m.category}</span></td>
                  <td style={{ fontWeight: 600 }}>{m.name}</td>
                  <td style={{ fontWeight: 700, fontFamily: 'monospace' }}>{m.value} {m.unit}</td>
                  <td><span className="badge badge-blue">{m.gri}</span></td>
                  <td>{m.verified ? <CheckCircle size={15} color="#00A598" /> : <span className="badge badge-gray">待驗</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}