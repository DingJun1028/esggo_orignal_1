'use client';
import { useState } from 'react';
import { CheckSquare, Clock, ChevronRight, Plus } from 'lucide-react';

const initial = [
  { id: 1, title: '完成溫室氣體範疇一盤查', status: 'in_progress', priority: 'critical', assignee: '環安衛主任', gri: 'GRI 305-1', due: '2025-12-31' },
  { id: 2, title: '提交台電帳單至證據金庫', status: 'todo', priority: 'high', assignee: '總務部門', gri: 'GRI 302-1', due: '2025-11-30' },
  { id: 3, title: '完成利害關係人問卷調查', status: 'review', priority: 'high', assignee: '永續委員會', gri: 'GRI 3-1', due: '2025-12-15' },
  { id: 4, title: '建立供應商 ESG 稽核機制', status: 'todo', priority: 'medium', assignee: '採購部門', gri: 'GRI 308-1', due: '2026-03-31' },
  { id: 5, title: '完成董事會 ESG 培訓', status: 'done', priority: 'medium', assignee: '董事會秘書室', gri: 'GRI 2-9', due: '2025-10-31' },
];

const cols = ['todo', 'in_progress', 'review', 'done'];
const colLabels: Record<string, string> = { todo: '待辦', in_progress: '進行中', review: '審查中', done: '完成' };
const priorityColors: Record<string, string> = { critical: '#ED4E33', high: '#FDB515', medium: '#3B7EA1', low: '#94a3b8' };

export default function TasksPage() {
  const [tasks, setTasks] = useState(initial);
  const [view, setView] = useState<'kanban' | 'list'>('kanban');

  const advance = (id: number) => {
    setTasks(prev => prev.map(t => {
      if (t.id !== id) return t;
      const idx = cols.indexOf(t.status);
      return { ...t, status: cols[Math.min(idx + 1, cols.length - 1)] };
    }));
  };

  return (
    <div className="fade-in" style={{ maxWidth: 1300 }}>
      <div className="page-header">
        <div className="page-eyebrow"><CheckSquare size={12} /> UCC 引擎 · 5T 任務追蹤</div>
        <h1 className="page-title">任務中心 Tasks</h1>
        <p className="page-sub">跨部門 ESG 任務協作 · Kanban 看板管理</p>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', flexWrap: 'wrap', gap: '0.75rem' }}>
        <div style={{ display: 'flex', gap: '0.5rem' }}>
          {(['kanban', 'list'] as const).map(v => (
            <button key={v} onClick={() => setView(v)} style={{
              padding: '0.4rem 0.875rem', borderRadius: 8, border: 'none', cursor: 'pointer',
              fontSize: '0.78rem', fontWeight: 600,
              background: view === v ? '#003262' : 'white', color: view === v ? 'white' : '#475569',
              boxShadow: '0 1px 3px rgba(0,0,0,0.06)',
            }}>{v === 'kanban' ? '看板' : '列表'}</button>
          ))}
        </div>
        <button className="btn btn-primary btn-sm"><Plus size={14} /> 新增任務</button>
      </div>

      {view === 'kanban' ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '0.875rem', overflowX: 'auto' }}>
          {cols.map(col => (
            <div key={col} style={{ minWidth: 180 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem', padding: '0 0.25rem' }}>
                <div style={{ fontWeight: 800, fontSize: '0.75rem', color: '#475569', textTransform: 'uppercase' }}>{colLabels[col]}</div>
                <span className="badge badge-gray">{tasks.filter(t => t.status === col).length}</span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.625rem' }}>
                {tasks.filter(t => t.status === col).map(task => (
                  <div key={task.id} className="card" style={{ padding: '0.875rem', borderLeft: `3px solid ${priorityColors[task.priority]}` }}>
                    <div style={{ fontWeight: 700, fontSize: '0.78rem', marginBottom: 6, lineHeight: 1.4 }}>{task.title}</div>
                    <div style={{ display: 'flex', gap: '0.35rem', flexWrap: 'wrap', marginBottom: 6 }}>
                      <span className="badge badge-blue badge-sm">{task.gri}</span>
                    </div>
                    <div style={{ fontSize: '0.65rem', color: '#94a3b8', marginBottom: 8 }}>
                      <Clock size={9} style={{ verticalAlign: 'middle', marginRight: 3 }} />
                      {task.due}
                    </div>
                    {task.status !== 'done' && (
                      <button className="btn btn-ghost btn-xs" onClick={() => advance(task.id)} style={{ width: '100%', fontSize: '0.68rem' }}>
                        推進 <ChevronRight size={10} />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
          <style>{`@media(max-width:768px){div[style*="gridTemplateColumns: repeat(4, 1fr)"]{grid-template-columns:repeat(2,1fr)!important}}`}</style>
        </div>
      ) : (
        <div className="card">
          <div className="tbl-wrap">
            <table className="tbl">
              <thead>
                <tr><th>任務</th><th>GRI</th><th>負責人</th><th>截止</th><th>狀態</th><th>操作</th></tr>
              </thead>
              <tbody>
                {tasks.map(task => (
                  <tr key={task.id}>
                    <td style={{ fontWeight: 600 }}>{task.title}</td>
                    <td><span className="badge badge-blue">{task.gri}</span></td>
                    <td style={{ color: '#475569', fontSize: '0.8rem' }}>{task.assignee}</td>
                    <td style={{ color: '#94a3b8', fontSize: '0.78rem' }}>{task.due}</td>
                    <td><span className="badge badge-gray">{colLabels[task.status]}</span></td>
                    <td>
                      {task.status !== 'done' && (
                        <button className="btn btn-ghost btn-xs" onClick={() => advance(task.id)}>推進</button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}