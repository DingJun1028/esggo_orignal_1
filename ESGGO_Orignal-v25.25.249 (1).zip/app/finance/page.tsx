'use client';
import { TrendingUp } from 'lucide-react';

const roi = [
  { item: '太陽能板安裝', cost: 5000000, saving: 1200000, payback: '4.2年', gri: 'GRI 302-1' },
  { item: 'LED 照明更換', cost: 800000, saving: 320000, payback: '2.5年', gri: 'GRI 302-1' },
  { item: '供應鏈碳管理', cost: 1200000, saving: 950000, payback: '1.3年', gri: 'GRI 305-3' },
];

export default function FinancePage() {
  return (
    <div className="fade-in" style={{ maxWidth: 1000 }}>
      <div className="page-header">
        <div className="page-eyebrow"><TrendingUp size={12} /> TCFD · GRI 201 · 永續財務</div>
        <h1 className="page-title">永續財務中心 Finance</h1>
        <p className="page-sub">ESG ROI 分析 · TCFD 氣候財務揭露 · 碳風險情境</p>
      </div>

      <div className="g-3" style={{ marginBottom: '1.5rem' }}>
        {[
          { label: '綠色投資回報', value: '₹2.47M', unit: '年度節省', color: '#00A598' },
          { label: '碳資產風險', value: '₹12M', unit: '潛在影響', color: '#ED4E33' },
          { label: 'TCFD 完成度', value: '78%', unit: '', color: '#003262' },
        ].map((s, i) => (
          <div key={i} className="card kpi-card" style={{ borderTop: `3px solid ${s.color}` }}>
            <div className="kpi-label">{s.label}</div>
            <div className="kpi-value" style={{ color: s.color }}>{s.value}</div>
            <div style={{ fontSize: '0.72rem', color: '#94a3b8' }}>{s.unit}</div>
          </div>
        ))}
      </div>

      <div className="card">
        <div style={{ padding: '1.5rem', fontWeight: 800, fontSize: '1rem', borderBottom: '1px solid #f1f5f9' }}>ESG 投資 ROI 分析</div>
        <div className="tbl-wrap">
          <table className="tbl">
            <thead><tr><th>投資項目</th><th>投入成本</th><th>年度節省</th><th>回收期</th><th>GRI</th></tr></thead>
            <tbody>
              {roi.map((r, i) => (
                <tr key={i}>
                  <td style={{ fontWeight: 700 }}>{r.item}</td>
                  <td style={{ fontFamily: 'monospace' }}>TWD {r.cost.toLocaleString()}</td>
                  <td style={{ fontWeight: 700, color: '#00A598', fontFamily: 'monospace' }}>TWD {r.saving.toLocaleString()}</td>
                  <td><span className="badge badge-gold">{r.payback}</span></td>
                  <td><span className="badge badge-blue">{r.gri}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}