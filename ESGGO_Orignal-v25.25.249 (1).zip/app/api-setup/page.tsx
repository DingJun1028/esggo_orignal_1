'use client';
import { Settings, CheckCircle, XCircle } from 'lucide-react';

const connectors = [
  { name: 'Supabase PostgreSQL', status: true, type: 'Database', desc: '主要資料庫 · RLS 啟用' },
  { name: 'Google Gemini AI', status: false, type: 'AI', desc: 'API Key 未設定' },
  { name: 'Supabase Auth', status: true, type: 'Auth', desc: 'Email + OAuth 已啟用' },
  { name: 'Supabase Realtime', status: true, type: 'Realtime', desc: '即時同步啟用中' },
];

export default function ApiSetupPage() {
  return (
    <div className="fade-in" style={{ maxWidth: 1000 }}>
      <div className="page-header">
        <div className="page-eyebrow"><Settings size={12} /> 系統整合 · API 管理</div>
        <h1 className="page-title">整合中心 API Setup</h1>
        <p className="page-sub">ERP 連接器 · API 金鑰管理 · Webhook 設定</p>
      </div>

      <div className="card">
        <div style={{ padding: '1.5rem', fontWeight: 800, fontSize: '1rem', borderBottom: '1px solid #f1f5f9' }}>系統連接器狀態</div>
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          {connectors.map((c, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '1.25rem 1.5rem', borderBottom: '1px solid #f8fafc' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                {c.status ? <CheckCircle size={18} color="#00A598" /> : <XCircle size={18} color="#ED4E33" />}
                <div>
                  <div style={{ fontWeight: 700 }}>{c.name}</div>
                  <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{c.desc}</div>
                </div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                <span className="badge badge-gray">{c.type}</span>
                <span className={`badge ${c.status ? 'badge-green' : 'badge-red'}`}>{c.status ? '已連接' : '未連接'}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}