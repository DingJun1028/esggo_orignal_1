'use client';
import { useState } from 'react';
import { Bot, Send, User, Zap, Shield, Heart, Lightbulb } from 'lucide-react';

const personas = [
  { id: 'compliance', name: '合規守衛', sub: 'Compliance Guard', icon: <Shield size={15} />, color: '#003262' },
  { id: 'harmony', name: '共榮引導', sub: 'Harmony Guide', icon: <Heart size={15} />, color: '#00A598' },
  { id: 'innovation', name: '創新先行', sub: 'Innovation Lead', icon: <Lightbulb size={15} />, color: '#FDB515' },
  { id: 'berkeley', name: 'Berkeley 顧問', sub: 'Haas Mentor', icon: <Zap size={15} />, color: '#822980' },
];

const quickPrompts = [
  'GRI 305-1 範疇一如何計算？',
  '如何降低供應鏈碳排放？',
  'ISSB S2 和 TCFD 的差異？',
  '中小企業 ESG 入門步驟？',
];

type Message = { role: 'user' | 'assistant'; content: string };

const replies: Record<string, string> = {
  compliance: `根據 GRI 2021 標準，您的問題涉及以下合規要點：\n\n**指標對齊**：確保數據符合 GRI 通用準則的揭露要求。\n\n**風險控管**：建議進行重大性評估，識別高衝擊議題並優先揭露。\n\n**5T 驗證**：所有數據應附上原始佐證文件，並記錄於證據金庫中。`,
  harmony: `從利害關係人的角度來看：\n\n**員工視角**：確保勞工權益相關指標（GRI 401-403）完整揭露。\n\n**社區影響**：關注在地採購比例與社區投入計畫。\n\n**供應鏈夥伴**：建立永續採購標準，邀請供應商共同參與 ESG 旅程。`,
  innovation: `從創新轉型角度分析：\n\n**數位化機會**：利用 IoT 感測器自動收集能源與碳排數據，減少人工填報錯誤。\n\n**循環經濟**：探索廢棄物再利用商業模式，創造新營收同時降低環境影響。\n\n**綠色金融**：ESG 評級提升可接觸更低利率的永續連結貸款。`,
  berkeley: `來自 Berkeley Haas 的策略洞見：\n\n**Open Innovation**：邀請外部生態系夥伴共同解決 ESG 挑戰。\n\n**Business Model Canvas**：重新設計商業模式，將永續性納入核心價值主張。\n\n**Impact Measurement**：採用 IRIS+ 框架量化社會與環境影響力。`,
};

export default function AdvisoryPage() {
  const [persona, setPersona] = useState('compliance');
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: '您好！我是您的 ESG 智慧顧問。請選擇對話模式並提出您的永續治理問題。' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const send = async (text: string) => {
    if (!text.trim() || loading) return;
    setMessages(prev => [...prev, { role: 'user', content: text }]);
    setInput('');
    setLoading(true);
    await new Promise(r => setTimeout(r, 1100));
    setMessages(prev => [...prev, { role: 'assistant', content: replies[persona] || replies.compliance }]);
    setLoading(false);
  };

  const currentPersona = personas.find(p => p.id === persona);

  return (
    <div className="fade-in" style={{ maxWidth: 1100, display: 'flex', flexDirection: 'column', gap: '1rem' }}>
      <div className="page-header">
        <div className="page-eyebrow"><Bot size={12} /> SPIRIT Personas · AI 驅動顧問</div>
        <h1 className="page-title">專家諮詢 Advisory</h1>
        <p className="page-sub">三大 AI 人格 × Berkeley Haas 策略顧問</p>
      </div>

      {/* Persona selector — wraps on mobile */}
      <div style={{ display: 'flex', gap: '0.625rem', flexWrap: 'wrap' }}>
        {personas.map(p => (
          <button key={p.id} onClick={() => setPersona(p.id)}
            className="card"
            style={{
              padding: '0.75rem 1rem', cursor: 'pointer', background: 'white',
              border: persona === p.id ? `2px solid ${p.color}` : '2px solid transparent',
              display: 'flex', alignItems: 'center', gap: 8, borderRadius: 10,
              minWidth: 0,
            }}>
            <span style={{ color: p.color, flexShrink: 0 }}>{p.icon}</span>
            <div style={{ textAlign: 'left', minWidth: 0 }}>
              <div style={{ fontSize: '0.78rem', fontWeight: 700, whiteSpace: 'nowrap' }}>{p.name}</div>
              <div style={{ fontSize: '0.6rem', color: '#94a3b8', whiteSpace: 'nowrap' }}>{p.sub}</div>
            </div>
          </button>
        ))}
      </div>

      {/* Chat area */}
      <div className="card" style={{ display: 'flex', flexDirection: 'column', minHeight: '50vh', maxHeight: '70vh' }}>
        <div style={{ flex: 1, overflowY: 'auto', padding: '1.25rem', display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
          {messages.map((msg, i) => (
            <div key={i} style={{ display: 'flex', gap: '0.625rem', flexDirection: msg.role === 'user' ? 'row-reverse' : 'row' }}>
              <div style={{
                width: 30, height: 30, borderRadius: '50%', flexShrink: 0,
                background: msg.role === 'user' ? '#003262' : (currentPersona?.color || '#003262'),
                display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white',
              }} aria-hidden="true">
                {msg.role === 'user' ? <User size={13} /> : <Bot size={13} />}
              </div>
              <div style={{
                maxWidth: '75%', padding: '0.75rem 0.875rem', borderRadius: 12,
                fontSize: '0.83rem', lineHeight: 1.7,
                background: msg.role === 'user' ? '#003262' : '#f8fafc',
                color: msg.role === 'user' ? 'white' : '#1e293b',
                whiteSpace: 'pre-wrap', wordBreak: 'break-word',
              }}>
                {msg.content}
              </div>
            </div>
          ))}
          {loading && (
            <div style={{ display: 'flex', gap: '0.625rem' }}>
              <div style={{ width: 30, height: 30, borderRadius: '50%', background: currentPersona?.color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Bot size={13} color="white" />
              </div>
              <div style={{ padding: '0.75rem 1rem', background: '#f8fafc', borderRadius: 12, display: 'flex', gap: 4, alignItems: 'center' }}>
                {[0,1,2].map(i => (
                  <div key={i} style={{ width: 7, height: 7, borderRadius: '50%', background: '#94a3b8', animation: `bounce 1s ${i*0.2}s infinite` }} />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Quick prompts */}
        <div style={{ padding: '0.625rem 1.25rem', borderTop: '1px solid #f1f5f9', display: 'flex', gap: '0.4rem', flexWrap: 'wrap' }}>
          {quickPrompts.map((q, i) => (
            <button key={i} onClick={() => send(q)} style={{
              padding: '0.25rem 0.625rem', background: '#f1f5f9', border: 'none',
              borderRadius: 99, fontSize: '0.7rem', cursor: 'pointer', color: '#475569',
            }}>{q}</button>
          ))}
        </div>

        {/* Input */}
        <div style={{ padding: '0.875rem 1.25rem', borderTop: '1px solid #f1f5f9', display: 'flex', gap: '0.625rem' }}>
          <input className="inp" value={input} onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send(input)}
            placeholder="輸入您的 ESG 問題..." style={{ flex: 1 }}
            aria-label="輸入問題" />
          <button onClick={() => send(input)} className="btn btn-primary btn-icon"
            disabled={!input.trim() || loading} aria-label="送出">
            <Send size={15} />
          </button>
        </div>
      </div>
      <style>{`@keyframes bounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-5px)} }`}</style>
    </div>
  );
}