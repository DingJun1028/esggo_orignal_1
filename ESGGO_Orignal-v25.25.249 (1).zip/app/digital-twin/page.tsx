'use client';
import { useState } from 'react';
import { Fingerprint, Brain, Send } from 'lucide-react';

export default function DigitalTwinPage() {
  const [stage] = useState<'dormant' | 'active'>('dormant');
  const [chat, setChat] = useState<{role: string; content: string}[]>([
    { role: 'twin', content: '您好！我是您的數位分身。目前處於覺醒初期階段，等待您上傳更多知識庫文件以提升一致性。' }
  ]);
  const [input, setInput] = useState('');

  const dna = { intelligence: 75, benevolence: 80, courage: 70, integrity: 90 };

  const send = () => {
    if (!input.trim()) return;
    setChat(prev => [...prev, { role: 'user', content: input }]);
    setInput('');
    setTimeout(() => {
      setChat(prev => [...prev, { role: 'twin', content: `根據我目前的知識庫，針對您的問題「${input}」，我的建議是基於 5T 誠信協議的角度來分析...` }]);
    }, 1000);
  };

  return (
    <div className="fade-in" style={{ maxWidth: 1100 }}>
      <div className="page-header">
        <div className="page-eyebrow"><Fingerprint size={12} /> 主權帳本 · RAG 知識倉庫 · 道德 DNA</div>
        <h1 className="page-title">數位分身 Digital Twin</h1>
        <p className="page-sub">個人化 AI 知識代理 · 去中心化身份 · 永恆智慧傳承</p>
      </div>

      <div className="g-2" style={{ gap: '1.5rem' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {/* Status */}
          <div className="card" style={{ padding: '1.5rem' }}>
            <div style={{ fontWeight: 800, marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: 8 }}>
              <Brain size={18} color="#003262" /> 分身狀態
            </div>
            <div style={{ textAlign: 'center', padding: '1rem' }}>
              <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>🧬</div>
              <div style={{ fontWeight: 700, color: '#003262' }}>{stage === 'dormant' ? '覺醒初期' : '活躍'}</div>
              <div style={{ fontSize: '0.75rem', color: '#94a3b8', marginTop: 4 }}>v1.0.0 · user_id: default</div>
            </div>
          </div>

          {/* DNA */}
          <div className="card" style={{ padding: '1.5rem' }}>
            <div style={{ fontWeight: 800, marginBottom: '1rem' }}>道德 DNA 矩陣</div>
            {Object.entries(dna).map(([key, val]) => (
              <div key={key} style={{ marginBottom: '0.875rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                  <span style={{ fontSize: '0.78rem', fontWeight: 600, textTransform: 'capitalize' }}>{key === 'intelligence' ? '智慧' : key === 'benevolence' ? '仁愛' : key === 'courage' ? '勇氣' : '誠信'}</span>
                  <span style={{ fontSize: '0.78rem', fontWeight: 700, color: '#003262' }}>{val}%</span>
                </div>
                <div className="progress-track">
                  <div className="progress-fill" style={{ width: `${val}%`, background: '#003262' }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Chat */}
        <div className="card" style={{ display: 'flex', flexDirection: 'column', minHeight: 500 }}>
          <div style={{ padding: '1.25rem', borderBottom: '1px solid #f1f5f9', fontWeight: 800 }}>與分身對話</div>
          <div style={{ flex: 1, overflowY: 'auto', padding: '1.25rem', display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
            {chat.map((msg, i) => (
              <div key={i} style={{ display: 'flex', gap: '0.75rem', flexDirection: msg.role === 'user' ? 'row-reverse' : 'row' }}>
                <div style={{ width: 30, height: 30, borderRadius: '50%', background: msg.role === 'user' ? '#003262' : '#FDB515', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: '0.75rem' }}>
                  {msg.role === 'user' ? '我' : '🧬'}
                </div>
                <div style={{ maxWidth: '75%', padding: '0.875rem', borderRadius: 12, fontSize: '0.83rem', lineHeight: 1.6, background: msg.role === 'user' ? '#003262' : '#f8fafc', color: msg.role === 'user' ? 'white' : '#1e293b' }}>
                  {msg.content}
                </div>
              </div>
            ))}
          </div>
          <div style={{ padding: '1rem', borderTop: '1px solid #f1f5f9', display: 'flex', gap: '0.75rem' }}>
            <input className="inp" placeholder="問問您的數位分身..." value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} style={{ flex: 1 }} />
            <button className="btn btn-primary" onClick={send}><Send size={14} /></button>
          </div>
        </div>
      </div>
    </div>
  );
}