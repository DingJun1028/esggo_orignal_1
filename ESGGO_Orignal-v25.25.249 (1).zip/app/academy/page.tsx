'use client';
import { GraduationCap } from 'lucide-react';

const instructors = [
  { name: '楊坤修 博士', title: '理事長', org: '台灣社會創新與永續發展協會', en: 'Dr. Kuen-Shiou Yang' },
  { name: 'Ganesh Iyer', title: 'Faculty Director', org: 'UC Berkeley Haas', en: 'Center for Growth Markets' },
  { name: 'Ana Torres', title: 'Lecturer', org: 'UC Berkeley Haas', en: 'Cleantech to Market Program' },
  { name: 'Stan Shih', title: 'Founder', org: 'Acer Group', en: 'StanShih Foundation' },
];

export default function AcademyPage() {
  return (
    <div className="fade-in" style={{ maxWidth: 1100 }}>
      <div className="page-header">
        <div className="page-eyebrow"><GraduationCap size={12} /> Berkeley Haas × TSISDA</div>
        <h1 className="page-title">永續學院 Academy</h1>
        <p className="page-sub">Berkeley ESG Strategy & Innovation Program · 2026 Cohort</p>
      </div>

      <div className="g-4" style={{ marginBottom: '1.5rem' }}>
        {[
          { label: 'Cohort A', value: '6月6日', sub: '- 7月11日 2026', color: '#003262' },
          { label: 'Cohort B', value: '8月1日', sub: '- 9月5日 2026', color: '#FDB515' },
          { label: '課程時數', value: '120h', sub: '理論+實務', color: '#00A598' },
          { label: '講師陣容', value: '10+', sub: '頂尖 ESG 專家', color: '#822980' },
        ].map((s, i) => (
          <div key={i} className="card kpi-card" style={{ borderTop: `3px solid ${s.color}` }}>
            <div className="kpi-label">{s.label}</div>
            <div className="kpi-value" style={{ color: s.color }}>{s.value}</div>
            <div style={{ fontSize: '0.72rem', color: '#94a3b8' }}>{s.sub}</div>
          </div>
        ))}
      </div>

      <div className="card" style={{ padding: '1.5rem' }}>
        <h3 style={{ fontWeight: 800, fontSize: '1rem', marginBottom: '1.25rem' }}>講師陣容</h3>
        <div className="g-2">
          {instructors.map((ins, i) => (
            <div key={i} className="card" style={{ padding: '1.25rem', display: 'flex', gap: '1rem', alignItems: 'center' }}>
              <div style={{ width: 48, height: 48, borderRadius: '50%', background: '#003262', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#FDB515', fontWeight: 800, flexShrink: 0 }}>
                {ins.name.charAt(0)}
              </div>
              <div>
                <div style={{ fontWeight: 800, fontSize: '0.9rem' }}>{ins.name}</div>
                <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{ins.title} · {ins.org}</div>
                <div style={{ fontSize: '0.7rem', color: '#94a3b8', fontStyle: 'italic' }}>{ins.en}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}